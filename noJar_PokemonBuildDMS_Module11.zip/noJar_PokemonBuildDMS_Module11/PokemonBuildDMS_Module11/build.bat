@echo off
setlocal
cd /d "%~dp0"
set "JAVA_FLAGS=--release 8"
javac -version 2>&1 | findstr /b /c:"javac 1.8." >nul
if not errorlevel 1 set "JAVA_FLAGS=-source 8 -target 8"
if exist build\classes rmdir /s /q build\classes
if exist build\jar-content rmdir /s /q build\jar-content
mkdir build\classes
mkdir build\jar-content
if not exist dist mkdir dist
javac -encoding UTF-8 %JAVA_FLAGS% -cp "lib\*" -d build\classes src\dms\*.java
if errorlevel 1 exit /b 1
pushd build\jar-content
for %%J in (sqlite-jdbc-3.50.3.0.jar slf4j-api-2.0.17.jar slf4j-nop-2.0.17.jar) do (
    jar xf "..\..\lib\%%J"
    if errorlevel 1 (popd & exit /b 1)
)
del /q META-INF\MANIFEST.MF 2>nul
del /q META-INF\*.SF META-INF\*.RSA META-INF\*.DSA 2>nul
popd
xcopy /e /i /q /y build\classes\dms build\jar-content\dms >nul
jar cfm dist\PokemonBuildDMS_Module11.jar META-INF\MANIFEST.MF -C build\jar-content .
if errorlevel 1 exit /b 1
echo Built dist\PokemonBuildDMS_Module11.jar - SQLite JDBC bundled
