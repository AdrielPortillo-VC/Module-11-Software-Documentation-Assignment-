@echo off
cd /d "%~dp0"
java -jar dist\PokemonBuildDMS_Module11.jar
if errorlevel 1 pause
