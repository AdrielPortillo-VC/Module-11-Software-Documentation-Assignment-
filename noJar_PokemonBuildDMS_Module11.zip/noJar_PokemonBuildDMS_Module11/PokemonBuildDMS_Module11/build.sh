#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
rm -rf build/classes build/jar-content
mkdir -p build/classes build/jar-content dist
if javac -version 2>&1 | sed -n '1p' | cut -d ' ' -f 2 | cut -d '.' -f 1 | grep -qx 1; then
  javac -encoding UTF-8 -source 8 -target 8 -cp 'lib/*' -d build/classes src/dms/*.java
else
  javac -encoding UTF-8 --release 8 -cp 'lib/*' -d build/classes src/dms/*.java
fi
for dependency in sqlite-jdbc-3.50.3.0.jar slf4j-api-2.0.17.jar slf4j-nop-2.0.17.jar; do
  (cd build/jar-content && jar xf "../../lib/$dependency")
done
rm -f build/jar-content/META-INF/MANIFEST.MF build/jar-content/META-INF/*.SF build/jar-content/META-INF/*.RSA build/jar-content/META-INF/*.DSA
cp -R build/classes/dms build/jar-content/
jar cfm dist/PokemonBuildDMS_Module11.jar META-INF/MANIFEST.MF -C build/jar-content .
printf '%s\n' 'Built dist/PokemonBuildDMS_Module11.jar (SQLite JDBC bundled)'
