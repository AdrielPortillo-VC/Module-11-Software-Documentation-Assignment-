# Pokemon Build DMS - Module 11: Software Documentation

Adriel Portillo Perez | CEN 3024C | November 16, 2026

This is the documented final version of the database-connected Pokemon Build Management System from Module 10. The application manages nine-field Pokemon builds through a Swing GUI and saves accepted changes immediately to a user-selected SQLite database.

## Open the documentation

Extract the complete project, then open **docs/javadoc/index.html** in a browser. The generated reference is inside the IntelliJ project and includes the application, retained console layers, test classes, and private implementation members. Keep the entire generated directory together so its links, styles, and search assets remain available.

The separate **PokemonBuildDMS_Module11_Javadoc.zip** is the Javadoc export for Canvas. Extract it and open **PokemonBuildDMS_Javadoc/index.html**.

## Documentation changes

- Every application and test class describes its purpose, dependencies, author, course, and documentation date.
- Constructors describe initialization and parameters; ordinary accessors and validated setters are documented as well.
- Method comments use `@param`, `@return` for non-void methods, and applicable `@throws` tags. Invalid `@return` tags on void methods were removed.
- Database documentation explains existing-file requirements, validation, defensive snapshots, immediate transactions, rollback, and read/write error contracts.
- Calculation documentation explains the weighted formula, selection rules, represented-type counting, and the limits of demonstration usage data.
- Package documentation, an overview, and reproducible generation scripts are included.

The existing method bodies, validation rules, SQL, GUI behavior, and 76 regression cases are retained. Seven previously implicit default constructors are explicit empty constructors so they can carry their own Javadoc. The production GUI retains its Module 10 window title because Module 11 adds documentation to that database phase.

## Open and run in IntelliJ

1. Extract the project completely and open its folder in IntelliJ.
2. Use the supplied **PokemonBuildDMS.iml** module. The `src` and `test` roots and bundled libraries are configured.
3. Select a full JDK for the project; JDK 21 was used for this documentation update.
4. Run the **PokemonBuildDMS** configuration, which starts `dms.Main`.
5. Browse to the supplied **pokemon_builds.db** and choose **Connect**. The original sample has 20 rows, five selections, and a readiness score rounded to **64.45 / 100**.

The application is compiled for Java 8 compatibility. The bundled runtime dependencies avoid a Maven download or a separate database server.

## Regenerate Javadoc in IntelliJ

The slides explicitly request creating the Javadoc within IntelliJ. A standard JDK-generated export is already supplied, but IntelliJ itself was not run during preparation. Regenerate it locally before the final export or commit:

1. Choose **Tools > Generate Javadoc**.
2. Select **Whole project**, enable **Include test sources**, and choose **Private** visibility.
3. Set the output directory to your project's **docs/javadoc** folder.
4. Enable author and version output. Add `-encoding UTF-8 -docencoding UTF-8 -charset UTF-8 -Xdoclint:all -Werror` to the command-line arguments. To include the overview, add `-overview` and the quoted absolute path to **docs/overview.html**.
5. Generate, check the Run output, and open **docs/javadoc/index.html**.

These options follow the [official JetBrains Javadocs guide](https://www.jetbrains.com/help/idea/javadocs.html). The documentation is deliberately included in version control rather than ignored.

From a terminal with a full JDK 21 on PATH, the equivalent repeatable generation is:

```text
generate-javadoc.bat
```

On macOS/Linux:

```sh
sh generate-javadoc.sh
```

The scripts use the bundled runtime and test JARs, include all Java sources through **javadoc-sources.txt**, and fail if documentation errors or warnings are found. If you change the source list, update that file as well. Re-create the separate Javadoc ZIP after regenerating so it matches your final code.

## Build and test

On Windows, use **build.bat**, **run.bat**, and **run-tests.bat**. On macOS/Linux:

```sh
sh build.sh
sh run.sh
sh run-tests.sh
```

The executable is **dist/PokemonBuildDMS_Module11.jar**. It bundles SQLite JDBC and logging dependencies; JUnit and Hamcrest remain test-only. The Swing tests require a graphical display. Tests use isolated fixture databases, preserving the submitted sample. See **TEST_RESULTS.md**, **test-output.txt**, and **docs/javadoc-generation.log** for current verification.

The original Phase 4 instructions and verification record are preserved in **docs/Module10_README.md** and **docs/Module10_TEST_RESULTS.md** as historical references. Their original filenames and submission status describe Module 10. **Module10_Recording_Guide.txt** is also historical; the Module 11 directions supplied for this task do not request a new video.

## Submit both required deliverables

1. **GitHub link:** commit and push the final documented project to the DMS repository, including **src**, **test**, and the complete **docs/javadoc** directory. Verify that the instructor can access the link.
2. **Javadoc export:** upload **PokemonBuildDMS_Module11_Javadoc.zip** to Canvas. Uploading only index.html omits its linked content.

The connected GitHub account returned no accessible owned or collaborator repositories, so **GitHub publishing is still pending**. No remote commit or Canvas submission has been made. The full project ZIP and separate export are ready; see **Module11_Submission_Guide.txt** for the local IntelliJ and submission steps.
