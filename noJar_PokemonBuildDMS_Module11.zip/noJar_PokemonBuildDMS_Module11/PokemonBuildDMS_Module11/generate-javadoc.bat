@echo off
setlocal
cd /d "%~dp0"
set "DMS_DOCUMENTATION_CLASSPATH=lib/sqlite-jdbc-3.50.3.0.jar;lib/slf4j-api-2.0.17.jar;lib/slf4j-nop-2.0.17.jar;lib/junit-4.13.2.jar;lib/hamcrest-core-1.3.jar"
where javadoc >nul 2>nul
if errorlevel 1 (
  echo Javadoc was not found. Use a full JDK 21 on PATH or generate within IntelliJ.
  exit /b 1
)
javadoc --release 8 -encoding UTF-8 -docencoding UTF-8 -charset UTF-8 -private -author -version -notimestamp -Xdoclint:all -Werror -windowtitle "Pokemon Build DMS - Module 11" -doctitle "Pokemon Build DMS: Module 11 Javadoc" -overview docs/overview.html -d docs/javadoc -classpath "%DMS_DOCUMENTATION_CLASSPATH%" @javadoc-sources.txt
if errorlevel 1 exit /b 1
echo Javadoc generated: docs\javadoc\index.html
endlocal
