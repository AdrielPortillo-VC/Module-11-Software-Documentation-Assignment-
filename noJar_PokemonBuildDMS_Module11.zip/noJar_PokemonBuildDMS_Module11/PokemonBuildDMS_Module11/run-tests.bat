@echo off
setlocal
cd /d "%~dp0"
call build.bat
if errorlevel 1 exit /b 1
set "JAVA_FLAGS=--release 8"
javac -version 2>&1 | findstr /b /c:"javac 1.8." >nul
if not errorlevel 1 set "JAVA_FLAGS=-source 8 -target 8"
if not exist build\test-classes mkdir build\test-classes
javac -encoding UTF-8 %JAVA_FLAGS% -cp "build\classes;lib\*" -d build\test-classes test\dms\*.java
if errorlevel 1 exit /b 1
java -cp "build\classes;build\test-classes;lib\*" org.junit.runner.JUnitCore dms.DmsTests dms.DatabaseTests dms.GuiTests
set "DMS_TEST_RESULT=%errorlevel%"
pause
exit /b %DMS_TEST_RESULT%
