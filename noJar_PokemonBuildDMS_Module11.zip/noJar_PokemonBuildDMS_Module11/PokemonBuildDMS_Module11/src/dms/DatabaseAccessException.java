package dms;

/**
 * DatabaseAccessException reports a database failure that the GUI can display.
 *
 * <p>{@link SqliteBuildRepository} preserves the original failure as the cause
 * when reading or closing a connection fails. The window catches this unchecked
 * exception at action boundaries and keeps the application available for recovery.</p>
 *
 * <p>Class: DatabaseAccessException. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class DatabaseAccessException extends RuntimeException {
    /**
     * DatabaseAccessException preserves an error explanation and its underlying cause.
     *
     * @param message explanation suitable for display to the user
     * @param cause underlying database or connection failure
     */
    public DatabaseAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
