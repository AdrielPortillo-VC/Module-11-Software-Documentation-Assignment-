package dms;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import org.sqlite.SQLiteConfig;
import org.sqlite.SQLiteOpenMode;

/**
 * SqliteBuildRepository persists build records in a user-selected SQLite database.
 *
 * <p>{@link #openDatabase(String)} accepts an existing readable, writable file
 * containing the expected nine-column {@code pokemon_builds} table. Schema,
 * stored records, and team size are validated before a replacement connection
 * is installed. A failed open keeps the earlier connection active.</p>
 *
 * <p>Reads query current database rows and return independent records. Writes use
 * prepared statements inside an immediate transaction so unique-ID and team-size
 * checks stay consistent with the saved change. A write reports success only
 * after commit; a rejected write is rolled back and explained by
 * {@link #getLastError()}. Read and close failures raise
 * {@link DatabaseAccessException}. This repository owns its JDBC connection and
 * must be {@linkplain #close() closed} when the caller finishes.</p>
 *
 * <p>Typical use (the database file must already exist):</p>
 * <pre>{@code
 * BuildValidator validator = new BuildValidator();
 * try (SqliteBuildRepository repository = new SqliteBuildRepository(validator)) {
 *     if (repository.openDatabase("pokemon_builds.db")) {
 *         System.out.println(repository.getAllBuilds().size());
 *     } else {
 *         System.out.println(repository.getLastError());
 *     }
 * }
 * }</pre>
 *
 * <p>Class: SqliteBuildRepository. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class SqliteBuildRepository implements AutoCloseable {
    /**
     * Shared field rules applied to both incoming and persisted data.
     */
    private final BuildValidator validator;
    /**
     * Explicit nine-column SQL order shared by reads and writes.
     */
    private final String columns = "build_id,species_name,primary_type,secondary_type,role,"
            + "base_stat_total,usage_rate,selected_for_team,last_updated";
    /**
     * Owned active connection, or null before opening or after closing.
     */
    private Connection connection;
    /**
     * Resolved real path of the active database, or null while disconnected.
     */
    private Path databasePath;
    /**
     * Last open or write rejection; reads and close use exceptions instead.
     */
    private String lastError = "";

    /**
     * SqliteBuildRepository starts disconnected; opening a file is a separate action.
     *
     * @param validator non-null shared field validator; the caller retains ownership
     */
    public SqliteBuildRepository(BuildValidator validator) { this.validator = validator; }
    /**
     * getLastError explains the most recent failed open or write.
     *
     * <p>Read and close failures are reported as {@link DatabaseAccessException}
     * instead of updating this text.</p>
     *
     * @return diagnostic text, or an empty string initially and after successful open or write
     */
    public String getLastError() { return lastError; }
    /**
     * isConnected reports whether this repository currently owns a connection.
     *
     * @return true after an accepted open and before a successful close
     */
    public boolean isConnected() { return connection != null; }
    /**
     * getDatabasePath identifies the currently connected database file.
     *
     * @return normalized real absolute path, or an empty string while disconnected
     */
    public String getDatabasePath() { return databasePath == null ? "" : databasePath.toString(); }

    /**
     * openDatabase validates an existing database before replacing the active connection.
     *
     * <p>The path may be relative or absolute and may have surrounding double quotes.
     * No missing file or table is created. The candidate must have the expected
     * schema, valid rows, no more than six selections, and available write access.
     * On failure, consult {@link #getLastError()}; the previous connection remains active.</p>
     *
     * @param location user-entered file path; null or blank is rejected
     * @return true after accepting the candidate; false when opening or validation fails
     */
    public boolean openDatabase(String location) {
        Connection candidate = null;
        try {
            if (location == null || location.trim().isEmpty()) {
                throw new IllegalArgumentException("Enter the location of an existing SQLite database.");
            }
            String entered = location.trim();
            if (entered.length() >= 2 && entered.startsWith("\"") && entered.endsWith("\"")) {
                entered = entered.substring(1, entered.length() - 1);
            }
            Path path = Paths.get(entered).toAbsolutePath().normalize();
            if (!Files.isRegularFile(path) || !Files.isReadable(path)) {
                throw new IllegalArgumentException("Choose an existing, readable database file. No file was created.");
            }
            if (!Files.isWritable(path)) {
                throw new IllegalArgumentException("Choose a writable copy of the database so changes can be saved.");
            }
            path = path.toRealPath();
            Class.forName("org.sqlite.JDBC");
            SQLiteConfig config = new SQLiteConfig();
            config.setOpenMode(SQLiteOpenMode.READWRITE);
            config.resetOpenMode(SQLiteOpenMode.CREATE);
            config.setBusyTimeout(1200);
            // URI encoding preserves spaces, #, ?, and non-ASCII characters in real paths.
            String jdbcUrl = "jdbc:sqlite:" + path.toUri().toASCIIString() + "?mode=rw";
            candidate = DriverManager.getConnection(jdbcUrl, config.toProperties());
            validateSchema(candidate);
            readRows(candidate);
            // BEGIN IMMEDIATE checks write access without changing any supplied data.
            try (Statement statement = candidate.createStatement()) {
                statement.execute("BEGIN IMMEDIATE");
                statement.execute("ROLLBACK");
            }
            if (connection != null) { connection.close(); }
            connection = candidate;
            candidate = null;
            databasePath = path;
            lastError = "";
            return true;
        } catch (SQLException | IOException | IllegalArgumentException | SecurityException ex) {
            lastError = "Cannot open database: " + readableError(ex);
            return false;
        } catch (ClassNotFoundException | LinkageError ex) {
            lastError = "Cannot open database: SQLite JDBC is unavailable. Use the supplied complete JAR or lib folder.";
            return false;
        } finally {
            if (candidate != null) {
                try { candidate.close(); } catch (SQLException ex) { /* Failed candidates are never installed. */ }
            }
        }
    }

    /**
     * validateSchema rejects unrelated databases rather than silently creating tables.
     *
     * @param source proposed database connection
     * @throws SQLException if the table, column set, or integer primary key is incompatible, or inspection fails
     */
    private void validateSchema(Connection source) throws SQLException {
        try (PreparedStatement query = source.prepareStatement(
                "SELECT type FROM sqlite_master WHERE name=?")) {
            query.setString(1, "pokemon_builds");
            try (ResultSet rows = query.executeQuery()) {
                if (!rows.next() || !"table".equals(rows.getString(1))) {
                    throw new SQLException("The pokemon_builds table is missing. Choose the supplied sample database.");
                }
            }
        }
        Set<String> actual = new HashSet<String>();
        boolean integerPrimaryKey = false;
        try (Statement query = source.createStatement();
             ResultSet rows = query.executeQuery("PRAGMA table_info(pokemon_builds)")) {
            while (rows.next()) {
                String name = rows.getString("name");
                actual.add(name);
                if ("build_id".equals(name) && rows.getInt("pk") == 1
                        && "INTEGER".equalsIgnoreCase(rows.getString("type"))) { integerPrimaryKey = true; }
            }
        }
        if (!actual.equals(new HashSet<String>(Arrays.asList(columns.split(",")))) || !integerPrimaryKey) {
            throw new SQLException("The database schema does not match this project. Choose pokemon_builds.db.");
        }
    }

    /**
     * readRows rejects corrupt field values and oversized teams on any database read.
     *
     * @param source open connection to query
     * @return independent validated records ordered by ID
     * @throws SQLException if a query fails, a stored field is invalid, or more than six builds are selected
     */
    private List<PokemonBuild> readRows(Connection source) throws SQLException {
        List<PokemonBuild> result = new ArrayList<PokemonBuild>();
        int selected = 0;
        try (Statement query = source.createStatement();
             ResultSet rows = query.executeQuery("SELECT " + columns + " FROM pokemon_builds ORDER BY build_id")) {
            while (rows.next()) {
                int id = requiredInteger(rows, "build_id", 1, Integer.MAX_VALUE);
                int bst = requiredInteger(rows, "base_stat_total", 1, 720);
                int flag = requiredInteger(rows, "selected_for_team", 0, 1);
                Optional<Double> usage = validator.parseDoubleInRange(rows.getString("usage_rate"), 0, 100);
                Optional<java.time.LocalDate> date = validator.parseDate(rows.getString("last_updated"));
                if (!usage.isPresent() || !date.isPresent() || rows.getString("secondary_type") == null) {
                    throw new SQLException("Invalid usage, date, or secondary type in database record #" + id + ".");
                }
                try {
                    result.add(new PokemonBuild(id, rows.getString("species_name"), rows.getString("primary_type"),
                            rows.getString("secondary_type"), rows.getString("role"), bst,
                            usage.get(), flag == 1, date.get()));
                } catch (IllegalArgumentException ex) {
                    throw new SQLException("Invalid database record #" + id + ": " + ex.getMessage(), ex);
                }
                if (flag == 1) { selected++; }
            }
        }
        if (selected > 6) { throw new SQLException("The database contains more than 6 selected builds. Correct the team first."); }
        return result;
    }

    /**
     * requiredInteger prevents SQLite numeric coercion from hiding malformed data.
     *
     * @param rows current result row
     * @param column required whole-number field
     * @param minimum inclusive allowed minimum
     * @param maximum inclusive allowed maximum
     * @return the validated integer
     * @throws SQLException if the column is unreadable or not an integer in the inclusive range
     */
    private int requiredInteger(ResultSet rows, String column, int minimum, int maximum) throws SQLException {
        Optional<Integer> value = validator.parseIntInRange(rows.getString(column), minimum, maximum);
        if (!value.isPresent()) { throw new SQLException("Invalid integer field " + column + " in database."); }
        return value.get();
    }

    /**
     * getAllBuilds reads a fresh, validated snapshot from the connected database.
     *
     * @return independent records ordered by ID; an empty list while disconnected
     * @throws DatabaseAccessException if a query fails or stored data violates field or team rules
     */
    public List<PokemonBuild> getAllBuilds() {
        if (!isConnected()) { return new ArrayList<PokemonBuild>(); }
        try { return readRows(connection); }
        catch (SQLException ex) { throw new DatabaseAccessException("Cannot read database: " + readableError(ex), ex); }
    }

    /**
     * findBuildById finds a record in a freshly validated database snapshot.
     *
     * @param id identifier to locate
     * @return independent matching record, or empty when absent or disconnected
     * @throws DatabaseAccessException if reading or validating the database fails
     */
    public Optional<PokemonBuild> findBuildById(int id) {
        for (PokemonBuild build : getAllBuilds()) {
            if (build.getBuildId() == id) { return Optional.of(build); }
        }
        return Optional.empty();
    }

    /**
     * containsId checks current persisted rows for an identifier.
     *
     * @param id identifier to locate
     * @return true when a matching row exists; false while disconnected
     * @throws DatabaseAccessException if reading or validating the database fails
     */
    public boolean containsId(int id) { return findBuildById(id).isPresent(); }

    /**
     * count queries the number of current persisted records.
     *
     * @return row count, or zero while disconnected
     * @throws DatabaseAccessException if reading or validating the database fails
     */
    public int count() { return getAllBuilds().size(); }

    /**
     * getSelectedBuilds queries the saved team independently of GUI filters.
     *
     * @return independent selected records ordered by ID; empty while disconnected
     * @throws DatabaseAccessException if reading or validating the database fails
     */
    public List<PokemonBuild> getSelectedBuilds() {
        List<PokemonBuild> result = new ArrayList<PokemonBuild>();
        for (PokemonBuild build : getAllBuilds()) { if (build.isSelectedForTeam()) { result.add(build); } }
        return result;
    }

    /**
     * addBuild inserts one complete record inside an immediate transaction.
     *
     * @param build proposed valid record; null is rejected
     * @return true after commit; false for disconnected storage, invalid fields,
     *         duplicate IDs, a seventh selection, or SQL failure; consult getLastError()
     */
    public boolean addBuild(PokemonBuild build) { return writeBuild(-1, build, false); }

    /**
     * updateBuild atomically replaces all nine fields of an existing record.
     *
     * @param originalId identifier of the saved row, even when the replacement changes its ID
     * @param build complete proposed replacement; null is rejected
     * @return true after commit; false for a missing row, invalid replacement,
     *         duplicate ID, team overflow, disconnection, or SQL failure; consult getLastError()
     */
    public boolean updateBuild(int originalId, PokemonBuild build) { return writeBuild(originalId, build, false); }

    /**
     * removeBuild deletes one saved record by identifier.
     *
     * <p>Confirmation is the caller's responsibility; this repository does not display dialogs.</p>
     *
     * @param id identifier of the record to delete
     * @return true after one deletion commits; false for a missing row,
     *         disconnection, or SQL failure; consult getLastError()
     */
    public boolean removeBuild(int id) { return writeBuild(id, null, true); }

    /**
     * writeBuild groups validation, duplicate/team checks, and SQL in one transaction.
     *
     * @param originalId existing ID, or -1 when inserting
     * @param build complete candidate, or null for deletion
     * @param removing whether this operation is a DELETE
     * @return true after commit; false rolls back and records a recoverable error
     */
    private boolean writeBuild(int originalId, PokemonBuild build, boolean removing) {
        if (!isConnected()) { lastError = "Connect to a SQLite database before changing builds."; return false; }
        if (!removing) {
            lastError = validator.getValidationError(build);
            if (!lastError.isEmpty()) { return false; }
        }
        boolean transaction = false;
        try (Statement control = connection.createStatement()) {
            // The write lock makes duplicate/team checks safe against a second connection.
            control.execute("BEGIN IMMEDIATE");
            transaction = true;
            List<PokemonBuild> current = readRows(connection);
            boolean found = false;
            int selected = !removing && build.isSelectedForTeam() ? 1 : 0;
            for (PokemonBuild stored : current) {
                if (stored.getBuildId() == originalId) { found = true; }
                if (!removing && stored.getBuildId() == build.getBuildId() && stored.getBuildId() != originalId) {
                    throw new IllegalArgumentException("Build ID " + build.getBuildId() + " already exists. Use a unique ID.");
                }
                if (stored.getBuildId() != originalId && stored.isSelectedForTeam()) { selected++; }
            }
            if (originalId != -1 && !found) { throw new IllegalArgumentException("Build ID " + originalId + " was not found."); }
            if (!removing && selected > 6) { throw new IllegalArgumentException("A team can have at most 6 selected builds. Deselect a build first."); }
            String sql = removing ? "DELETE FROM pokemon_builds WHERE build_id=?"
                    : originalId == -1 ? "INSERT INTO pokemon_builds (" + columns + ") VALUES (?,?,?,?,?,?,?,?,?)"
                    : "UPDATE pokemon_builds SET build_id=?,species_name=?,primary_type=?,secondary_type=?,role=?,"
                            + "base_stat_total=?,usage_rate=?,selected_for_team=?,last_updated=? WHERE build_id=?";
            try (PreparedStatement command = connection.prepareStatement(sql)) {
                if (removing) { command.setInt(1, originalId); }
                else {
                    bindBuild(command, build);
                    if (originalId != -1) { command.setInt(10, originalId); }
                }
                if (command.executeUpdate() != 1) { throw new SQLException("The record changed in another application. Refresh and try again."); }
            }
            control.execute("COMMIT");
            transaction = false;
            lastError = "";
            return true;
        } catch (SQLException | IllegalArgumentException ex) {
            lastError = "Change was not saved: " + readableError(ex);
            return false;
        } finally {
            if (transaction) {
                try (Statement rollback = connection.createStatement()) { rollback.execute("ROLLBACK"); }
                catch (SQLException ex) { lastError += " Reconnect to the database before trying again."; }
            }
        }
    }

    /**
     * bindBuild binds values as data so no user input becomes executable SQL.
     *
     * @param command INSERT or UPDATE prepared statement
     * @param build validated record to persist
     * @throws SQLException if JDBC cannot bind one of the nine prepared-statement values
     */
    private void bindBuild(PreparedStatement command, PokemonBuild build) throws SQLException {
        command.setInt(1, build.getBuildId());
        command.setString(2, build.getSpeciesName());
        command.setString(3, build.getPrimaryType());
        command.setString(4, build.getSecondaryType());
        command.setString(5, build.getRole());
        command.setInt(6, build.getBaseStatTotal());
        command.setDouble(7, build.getUsageRate());
        command.setInt(8, build.isSelectedForTeam() ? 1 : 0);
        command.setString(9, build.getLastUpdated().toString());
    }

    /**
     * readableError translates common driver messages into useful GUI corrections.
     *
     * @param failure database, path, or validation exception
     * @return a nonempty explanation suitable for the activity report
     */
    private String readableError(Exception failure) {
        String message = failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("busy") || lower.contains("locked")) {
            return "The database is busy or locked. Finish the other database transaction and try again.";
        }
        if (lower.contains("not a database") || lower.contains("malformed")) {
            return "This file is not a valid SQLite database. Choose the supplied pokemon_builds.db.";
        }
        if (lower.contains("readonly") || lower.contains("read-only")) {
            return "The database or its folder is read-only. Choose a writable copy.";
        }
        return message;
    }

    /**
     * close releases the owned JDBC connection and clears the active path.
     *
     * <p>Calling close again after a successful close has no effect.</p>
     *
     * @throws DatabaseAccessException if JDBC cannot close the connection
     */
    @Override public void close() {
        if (connection != null) {
            try { connection.close(); }
            catch (SQLException ex) { throw new DatabaseAccessException("Cannot close database: " + readableError(ex), ex); }
            connection = null;
            databasePath = null;
        }
    }
}
