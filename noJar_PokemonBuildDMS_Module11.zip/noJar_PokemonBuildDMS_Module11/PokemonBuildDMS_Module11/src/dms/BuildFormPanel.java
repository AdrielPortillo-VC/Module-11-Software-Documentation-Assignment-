package dms;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * BuildFormPanel edits all nine build attributes through validated Swing controls.
 *
 * <p>{@link #readBuild()} parses the entire form into a {@link PokemonBuild}
 * before a caller saves it. Invalid input focuses the relevant control and
 * raises a readable validation error. {@link PokemonBuildFrame} handles persistence
 * and user feedback; this panel does not write to a repository. Construct and
 * access its controls on Swing's event dispatch thread.</p>
 *
 * <p>Class: BuildFormPanel. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class BuildFormPanel extends JPanel {
    /**
     * Shared parser and catalog used by form controls.
     */
    private final BuildValidator validator;
    /**
     * Caption distinguishing a new draft from an existing build.
     */
    private final JLabel heading = new JLabel("New build");
    /**
     * Editable identifier; uniqueness is checked when saving.
     */
    private final JTextField buildId = new JTextField(15);
    /**
     * Fixed species catalog with an initial placeholder.
     */
    private final JComboBox<String> species;
    /**
     * Required primary-type choice with an initial placeholder.
     */
    private final JComboBox<String> primaryType;
    /**
     * Optional secondary-type choice; None represents an empty type.
     */
    private final JComboBox<String> secondaryType;
    /**
     * Fixed role choices used in the readiness calculation.
     */
    private final JComboBox<String> role;
    /**
     * Text input for a whole-number stat total from 1 to 720.
     */
    private final JTextField baseStatTotal = new JTextField(15);
    /**
     * Text input for the stored demonstration usage percentage.
     */
    private final JTextField usageRate = new JTextField(15);
    /**
     * Team membership flag; the repository enforces the six-member limit.
     */
    private final JCheckBox selected = new JCheckBox("Include in current team");
    /**
     * ISO date input, validated from 1900-01-01 through today.
     */
    private final JTextField lastUpdated = new JTextField(15);

    /**
     * BuildFormPanel creates an empty nine-field editor and initializes catalog menus.
     *
     * @param validator non-null shared field validator; the caller retains ownership
     */
    public BuildFormPanel(BuildValidator validator) {
        this.validator = validator;
        species = choices(validator.getSpecies(), "Choose species...");
        primaryType = choices(validator.getTypes(), "Choose type...");
        secondaryType = choices(validator.getTypes(), "None");
        role = choices(validator.getRoles(), "Choose role...");
        setLayout(new BorderLayout(0, 12));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 12, 16));
        heading.setFont(heading.getFont().deriveFont(java.awt.Font.BOLD, 18f));
        add(heading, BorderLayout.NORTH);
        JPanel fields = new JPanel(new GridBagLayout());
        fields.setOpaque(false);
        addField(fields, 0, "Build ID", buildId, "Positive, unique whole number", "buildId");
        addField(fields, 1, "Species", species, "Choose from the supported catalog", "speciesName");
        addField(fields, 2, "Primary type", primaryType, "Required Pokemon type", "primaryType");
        addField(fields, 3, "Secondary type", secondaryType, "Choose None for a single type", "secondaryType");
        addField(fields, 4, "Role", role, "Role used in the readiness calculation", "role");
        addField(fields, 5, "Base stat total", baseStatTotal, "Whole number: 1 to 720", "baseStatTotal");
        addField(fields, 6, "Usage rate (%)", usageRate, "Number: 0 to 100; e.g. 12.5", "usageRate");
        selected.setOpaque(false);
        addField(fields, 7, "Team selection", selected, "Up to 6 records may be selected", "selectedForTeam");
        addField(fields, 8, "Last updated", lastUpdated, "YYYY-MM-DD; 1900-01-01 through today", "lastUpdated");
        GridBagConstraints spacer = new GridBagConstraints();
        spacer.gridy = 9;
        spacer.weighty = 1;
        fields.add(new JLabel(), spacer);
        add(fields, BorderLayout.CENTER);
        reset(1);
    }

    /**
     * choices creates a fixed menu so arbitrary catalog values cannot be typed.
     *
     * @param allowed permitted values supplied by the shared validator
     * @param first placeholder or optional empty choice
     * @return a noneditable combo box containing the permitted choices
     */
    private JComboBox<String> choices(List<String> allowed, String first) {
        JComboBox<String> box = new JComboBox<String>();
        box.addItem(first);
        for (String value : allowed) { box.addItem(value); }
        box.setEditable(false);
        box.setMaximumRowCount(12);
        return box;
    }

    /**
     * addField aligns an accessible label with its named input component.
     *
     * @param panel form grid receiving the row
     * @param row zero-based row position
     * @param text visible field label
     * @param input component used to enter the attribute
     * @param hint explanation of allowed input
     * @param name stable component name for accessibility and GUI testing
     */
    private void addField(JPanel panel, int row, String text, JComponent input,
                          String hint, String name) {
        input.setName(name);
        input.setToolTipText(hint);
        input.getAccessibleContext().setAccessibleName(text);
        JLabel label = new JLabel(text);
        label.setLabelFor(input);
        GridBagConstraints left = new GridBagConstraints();
        left.gridx = 0;
        left.gridy = row;
        left.anchor = GridBagConstraints.WEST;
        left.insets = new Insets(7, 0, 7, 10);
        panel.add(label, left);
        GridBagConstraints right = new GridBagConstraints();
        right.gridx = 1;
        right.gridy = row;
        right.weightx = 1;
        right.fill = GridBagConstraints.HORIZONTAL;
        right.insets = new Insets(7, 0, 7, 0);
        panel.add(input, right);
    }

    /**
     * readBuild parses every field before a caller attempts an atomic save.
     *
     * @return a complete validated PokemonBuild reflecting the form
     * @throws IllegalArgumentException with a field-specific correction message
     */
    public PokemonBuild readBuild() {
        Optional<Integer> id = validator.parseIntInRange(buildId.getText(), 1, Integer.MAX_VALUE);
        if (!id.isPresent()) { throw invalid(buildId, "Build ID must be a positive whole number."); }
        if (species.getSelectedIndex() < 1) { throw invalid(species, "Choose a species from the supported catalog."); }
        if (primaryType.getSelectedIndex() < 1) { throw invalid(primaryType, "Choose a primary type."); }
        if (role.getSelectedIndex() < 1) { throw invalid(role, "Choose a role."); }
        if (primaryType.getSelectedItem().equals(secondaryType.getSelectedItem())) {
            throw invalid(secondaryType, "Primary and secondary types must be different.");
        }
        Optional<Integer> bst = validator.parseIntInRange(baseStatTotal.getText(), 1, 720);
        if (!bst.isPresent()) { throw invalid(baseStatTotal, "Base stat total must be a whole number from 1 through 720."); }
        Optional<Double> usage = validator.parseDoubleInRange(usageRate.getText(), 0, 100);
        if (!usage.isPresent()) { throw invalid(usageRate, "Usage rate must be a finite number from 0 through 100."); }
        Optional<LocalDate> date = validator.parseDate(lastUpdated.getText());
        if (!date.isPresent()) { throw invalid(lastUpdated, "Last updated must be a real YYYY-MM-DD date from 1900-01-01 through today."); }
        return new PokemonBuild(id.get(), (String) species.getSelectedItem(),
                (String) primaryType.getSelectedItem(), (String) secondaryType.getSelectedItem(),
                (String) role.getSelectedItem(), bst.get(), usage.get(), selected.isSelected(), date.get());
    }

    /**
     * invalid moves keyboard focus to the field requiring correction.
     *
     * @param input invalid component
     * @param message readable reason the proposed record was rejected
     * @return an exception for the window to display without closing the form
     */
    private IllegalArgumentException invalid(JComponent input, String message) {
        input.requestFocusInWindow();
        if (input instanceof JTextField) { ((JTextField) input).selectAll(); }
        return new IllegalArgumentException(message);
    }

    /**
     * showBuild fills all fields without modifying the stored record.
     *
     * @param build independent copy of the record selected for editing
     */
    public void showBuild(PokemonBuild build) {
        heading.setText("Editing build #" + build.getBuildId());
        buildId.setText(Integer.toString(build.getBuildId()));
        for (int index = 1; index < species.getItemCount(); index++) {
            if (species.getItemAt(index).equalsIgnoreCase(build.getSpeciesName())) {
                species.setSelectedIndex(index);
                break;
            }
        }
        primaryType.setSelectedItem(build.getPrimaryType());
        secondaryType.setSelectedItem(build.getSecondaryType().isEmpty() ? "None" : build.getSecondaryType());
        role.setSelectedItem(build.getRole());
        baseStatTotal.setText(Integer.toString(build.getBaseStatTotal()));
        usageRate.setText(Double.toString(build.getUsageRate()));
        selected.setSelected(build.isSelectedForTeam());
        lastUpdated.setText(build.getLastUpdated().toString());
    }

    /**
     * reset clears a previous edit and suggests an unused record ID.
     *
     * @param nextId suggested positive ID for a new record
     */
    public void reset(int nextId) {
        heading.setText("New build");
        buildId.setText(Integer.toString(nextId));
        species.setSelectedIndex(0);
        primaryType.setSelectedIndex(0);
        secondaryType.setSelectedIndex(0);
        role.setSelectedIndex(0);
        baseStatTotal.setText("");
        usageRate.setText("");
        selected.setSelected(false);
        lastUpdated.setText(LocalDate.now().toString());
    }
}
