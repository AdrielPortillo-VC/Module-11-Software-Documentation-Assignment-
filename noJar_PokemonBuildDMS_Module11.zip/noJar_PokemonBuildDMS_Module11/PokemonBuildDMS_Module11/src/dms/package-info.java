/**
 * Provides the Pokemon Build Management System's model, validation, persistence,
 * Swing interface, readiness calculation, and retained console regression layers.
 *
 * <p>{@link dms.Main} starts the production GUI. {@link dms.PokemonBuildFrame}
 * delegates validated changes to {@link dms.SqliteBuildRepository}; its table
 * contains a copied display snapshot. {@link dms.PokemonBuildRepository},
 * {@link dms.BuildFileService}, and {@link dms.PokemonBuildApp} remain for
 * historical console-phase regression coverage.</p>
 *
 * <p>JUnit classes in the separate test source folder use isolated fixtures.
 * Documentation updated November 16, 2026, for CEN 3024C.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
package dms;
