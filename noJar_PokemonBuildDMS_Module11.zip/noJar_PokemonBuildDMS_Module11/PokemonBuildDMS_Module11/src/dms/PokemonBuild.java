package dms;

import java.time.LocalDate;
import java.util.Locale;

/**
 * PokemonBuild represents the nine stored attributes of one Pokemon build.
 *
 * <p>{@link BuildValidator} checks construction and individual setters. Rejected
 * setter values leave the previous state intact. This object does not enforce
 * collection-wide unique IDs or the six-member team limit; the repository applies
 * those rules when saving a complete record. Call {@link #copy()} to edit an
 * independent draft without changing a displayed or stored object.</p>
 *
 * <p>Class: PokemonBuild. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class PokemonBuild {
    /**
     * Positive identifier; uniqueness belongs to the repository.
     */
    private int buildId;
    /**
     * Trimmed species or form name accepted by the project catalog.
     */
    private String speciesName;
    /**
     * Required type in canonical spelling.
     */
    private String primaryType;
    /**
     * Different optional type, or an empty string for no second type.
     */
    private String secondaryType;
    /**
     * Canonical planning role used by the readiness calculation.
     */
    private String role;
    /**
     * Whole-number total constrained to 1 through 720.
     */
    private int baseStatTotal;
    /**
     * Finite stored demonstration percentage from 0 through 100.
     */
    private double usageRate;
    /**
     * Whether this build participates in the selected-team calculation.
     */
    private boolean selectedForTeam;
    /**
     * Record date within the supported historical range.
     */
    private LocalDate lastUpdated;
    /**
     * Field rules reused by construction and validated setters.
     */
    private final BuildValidator validator = new BuildValidator();

    /**
     * PokemonBuild creates a complete validated record for display or persistence.
     *
     * <p>Text is trimmed, recognized type and role names are normalized, and an
     * optional secondary type becomes an empty string. Species spelling is preserved.
     * Repository-wide uniqueness and team-size checks occur when saving.</p>
     *
     * @param buildId positive identifier; uniqueness is checked by the repository
     * @param speciesName supported species name, compared without regard to case
     * @param primaryType required recognized primary type
     * @param secondaryType different recognized type, blank, None, or null for no second type
     * @param role one of the six supported planning roles
     * @param baseStatTotal whole-number total from 1 through 720
     * @param usageRate finite demonstration percentage from 0 through 100
     * @param selectedForTeam whether this record is selected for scoring
     * @param lastUpdated non-null date from 1900-01-01 through the current local date
     * @throws IllegalArgumentException if any field fails the shared validation rules
     */
    public PokemonBuild(int buildId, String speciesName, String primaryType,
                        String secondaryType, String role, int baseStatTotal,
                        double usageRate, boolean selectedForTeam, LocalDate lastUpdated) {
        this.buildId = buildId;
        this.speciesName = speciesName == null ? "" : speciesName.trim();
        this.primaryType = validator.normalizeType(primaryType);
        this.secondaryType = validator.normalizeType(secondaryType);
        this.role = validator.normalizeRole(role);
        this.baseStatTotal = baseStatTotal;
        this.usageRate = usageRate;
        this.selectedForTeam = selectedForTeam;
        this.lastUpdated = lastUpdated;
        String error = validator.getValidationError(this);
        if (!error.isEmpty()) {
            throw new IllegalArgumentException(error);
        }
    }

    /**
     * getBuildId exposes the current positive build identifier.
     *
     * @return positive build identifier
     */
    public int getBuildId() { return buildId; }
    /**
     * getSpeciesName exposes the current trimmed supported species name.
     *
     * @return trimmed supported species name
     */
    public String getSpeciesName() { return speciesName; }
    /**
     * getPrimaryType exposes the current canonical required primary type.
     *
     * @return canonical required primary type
     */
    public String getPrimaryType() { return primaryType; }
    /**
     * getSecondaryType exposes the current canonical secondary type.
     *
     * @return canonical secondary type, or an empty string when absent
     */
    public String getSecondaryType() { return secondaryType; }
    /**
     * getRole exposes the current canonical planning role.
     *
     * @return canonical planning role
     */
    public String getRole() { return role; }
    /**
     * getBaseStatTotal exposes the current base stat total from 1 through 720.
     *
     * @return base stat total from 1 through 720
     */
    public int getBaseStatTotal() { return baseStatTotal; }
    /**
     * getUsageRate exposes the current finite stored demonstration usage percentage from 0 through 100.
     *
     * @return finite stored demonstration usage percentage from 0 through 100
     */
    public double getUsageRate() { return usageRate; }
    /**
     * isSelectedForTeam reports whether this build is included in the selected team.
     *
     * @return true when this build participates in the selected team
     */
    public boolean isSelectedForTeam() { return selectedForTeam; }
    /**
     * getLastUpdated exposes the current record date; LocalDate is immutable.
     *
     * @return record date; LocalDate is immutable
     */
    public LocalDate getLastUpdated() { return lastUpdated; }

    /**
     * setBuildId changes the identifier when positive; the repository checks uniqueness.
     *
     * @param buildId proposed positive identifier
     * @return true if accepted; false leaves the previous value unchanged
     */
    public boolean setBuildId(int buildId) {
        if (!validator.isValidId(buildId)) { return false; }
        this.buildId = buildId;
        return true;
    }

    /**
     * setSpeciesName accepts a supported species and trims its spelling.
     *
     * @param speciesName proposed supported species name
     * @return true if accepted; false leaves the previous value unchanged
     */
    public boolean setSpeciesName(String speciesName) {
        if (!validator.isValidSpeciesName(speciesName)) { return false; }
        this.speciesName = speciesName.trim();
        return true;
    }

    /**
     * setTypes validates both types before replacing either field.
     *
     * @param primary required recognized primary type
     * @param secondary different recognized type, blank, or None for no second type
     * @return true when both fields are accepted; false preserves both previous types
     */
    public boolean setTypes(String primary, String secondary) {
        if (!validator.isValidType(primary, false) || !validator.isValidType(secondary, true)) {
            return false;
        }
        String first = validator.normalizeType(primary);
        String second = validator.normalizeType(secondary);
        if (first.equals(second)) { return false; }
        primaryType = first;
        secondaryType = second;
        return true;
    }

    /**
     * setRole accepts and normalizes one of the six planning roles.
     *
     * @param role proposed supported planning role
     * @return true if accepted; false leaves the previous value unchanged
     */
    public boolean setRole(String role) {
        if (!validator.isValidRole(role)) { return false; }
        this.role = validator.normalizeRole(role);
        return true;
    }

    /**
     * setBaseStatTotal accepts a stat total within the project range.
     *
     * @param baseStatTotal proposed whole-number total from 1 through 720
     * @return true if accepted; false leaves the previous value unchanged
     */
    public boolean setBaseStatTotal(int baseStatTotal) {
        if (!validator.isValidBaseStatTotal(baseStatTotal)) { return false; }
        this.baseStatTotal = baseStatTotal;
        return true;
    }

    /**
     * setUsageRate accepts a finite percentage within the project range.
     *
     * @param usageRate proposed finite percentage from 0 through 100
     * @return true if accepted; false leaves the previous value unchanged
     */
    public boolean setUsageRate(double usageRate) {
        if (!validator.isValidUsageRate(usageRate)) { return false; }
        this.usageRate = usageRate;
        return true;
    }

    /**
     * setSelectedForTeam changes this record's team-selection flag.
     *
     * <p>The repository checks the six-member limit when saving the complete record.</p>
     *
     * @param selectedForTeam requested selection status
     * @return true; either boolean value is valid for an individual build
     */
    public boolean setSelectedForTeam(boolean selectedForTeam) {
        this.selectedForTeam = selectedForTeam;
        return true;
    }

    /**
     * setLastUpdated accepts a date within the supported range.
     *
     * @param lastUpdated proposed non-null date from 1900-01-01 through today
     * @return true if accepted; false leaves the previous value unchanged
     */
    public boolean setLastUpdated(LocalDate lastUpdated) {
        if (!validator.isValidDate(lastUpdated)) { return false; }
        this.lastUpdated = lastUpdated;
        return true;
    }

    /**
     * copy isolates edits from the repository until a complete update is accepted.
     *
     * @return an independent build with identical values
     */
    public PokemonBuild copy() {
        return new PokemonBuild(buildId, speciesName, primaryType, secondaryType,
                role, baseStatTotal, usageRate, selectedForTeam, lastUpdated);
    }

    /**
     * toCsvLine formats the nine fields in the text-file import order.
     *
     * @return a comma-separated record without a header
     */
    public String toCsvLine() {
        return buildId + "," + speciesName + "," + primaryType + "," + secondaryType
                + "," + role + "," + baseStatTotal + "," + Double.toString(usageRate)
                + "," + selectedForTeam + "," + lastUpdated;
    }

    /**
     * toDisplayRow formats every stored field for the console table.
     *
     * @return one complete table row
     */
    public String toDisplayRow() {
        String types = primaryType + (secondaryType.isEmpty() ? "" : "/" + secondaryType);
        return String.format(Locale.US,
                "%-10d | %-20s | %-18s | %-7s | %3d | %7.2f | %-5s | %s",
                buildId, speciesName, types, role, baseStatTotal, usageRate,
                selectedForTeam, lastUpdated);
    }
}
