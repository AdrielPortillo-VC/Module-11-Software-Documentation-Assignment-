package dms;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.TableRowSorter;

/**
 * PokemonBuildFrame coordinates the production database-connected Swing interface.
 *
 * <p>{@link BuildFormPanel} gathers input, {@link BuildTableModel} displays copied
 * records, {@link SqliteBuildRepository} persists accepted CRUD actions, and
 * {@link TeamReadinessCalculator} evaluates the saved selected team. Display
 * filters affect the table snapshot, while calculations use all saved selections.
 * Successful writes invalidate a previous score. Recoverable errors remain in
 * the GUI, and deletion and exit require confirmation.</p>
 *
 * <p>Create and use this window on Swing's event dispatch thread in a graphical
 * environment. Constructing the window suggests a nearby database path but does
 * not open that database; the user must choose Connect.</p>
 *
 * <p>Class: PokemonBuildFrame. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class PokemonBuildFrame extends JFrame {
    /**
     * Rules shared by the editor and lookup controls.
     */
    private final BuildValidator validator;
    /**
     * SQLite source of truth for production reads and writes.
     */
    private final SqliteBuildRepository repository;
    /**
     * Calculates the saved selected team independently of display filters.
     */
    private final TeamReadinessCalculator calculator;
    /**
     * Nine-field editor for complete proposed records.
     */
    private final BuildFormPanel form;
    /**
     * Copied snapshot currently available to the table.
     */
    private final BuildTableModel model = new BuildTableModel();
    /**
     * Read-only, single-selection table displaying all nine attributes.
     */
    private final JTable table = new JTable(model);
    /**
     * View ordering and filters applied to model rows.
     */
    private final TableRowSorter<BuildTableModel> sorter = new TableRowSorter<BuildTableModel>(model);
    /**
     * User-editable path to an existing SQLite database.
     */
    private final JTextField databasePath = new JTextField(48);
    /**
     * Separate identifier input for lookup and confirmed removal.
     */
    private final JTextField targetId = new JTextField(8);
    /**
     * Literal case-insensitive species-name filter input.
     */
    private final JTextField search = new JTextField(11);
    /**
     * Filter matching either type field.
     */
    private final JComboBox<String> typeFilter = new JComboBox<String>();
    /**
     * Optional planning-role filter.
     */
    private final JComboBox<String> roleFilter = new JComboBox<String>();
    /**
     * Restricts visible rows to saved team selections when checked.
     */
    private final JCheckBox teamOnly = new JCheckBox("Team only");
    /**
     * Total collection and selected-team summary.
     */
    private final JLabel counts = new JLabel();
    /**
     * Number of rows remaining after view filters.
     */
    private final JLabel visibleCount = new JLabel();
    /**
     * Most recent score, or a placeholder when recalculation is required.
     */
    private final JLabel scoreValue = new JLabel("-- / 100");
    /**
     * Selectable explanation of weighted score components.
     */
    private final JTextArea scoreReport = new JTextArea();
    /**
     * Persistent activity and error history for the current window.
     */
    private final JTextArea activity = new JTextArea();
    /**
     * Current outcome or input correction displayed in the window footer.
     */
    private final JTextArea status = new JTextArea(2, 50);
    /**
     * Tabs containing readiness and database activity reports.
     */
    private final JTabbedPane reports = new JTabbedPane();
    /**
     * Original saved identifier of the draft, or null for a new build.
     */
    private Integer editingId;
    /**
     * Prevents selection and filter listeners from acting during refresh.
     */
    private boolean refreshing;

    /**
     * PokemonBuildFrame builds a database-connected window without opening a database.
     *
     * <p>Call on Swing's event dispatch thread. The window remains hidden until
     * {@code setVisible(true)} is called. Confirmed exit closes the supplied repository.</p>
     *
     * @param validator non-null shared field validator
     * @param repository non-null repository owned by the window after construction
     * @param calculator non-null readiness calculator
     * @throws java.awt.HeadlessException if no graphical environment is available
     */
    public PokemonBuildFrame(BuildValidator validator, SqliteBuildRepository repository,
                             TeamReadinessCalculator calculator) {
        super("Pokemon Build DMS | Module 10");
        this.validator = validator;
        this.repository = repository;
        this.calculator = calculator;
        this.form = new BuildFormPanel(validator);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        Rectangle desktop = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int availableWidth = Math.max(320, desktop.width - 24);
        int availableHeight = Math.max(300, desktop.height - 24);
        setMinimumSize(new Dimension(Math.min(1140, availableWidth), Math.min(720, availableHeight)));
        setSize(Math.min(1320, availableWidth), Math.min(800, availableHeight));
        setLocationRelativeTo(null);
        setJMenuBar(buildMenu());
        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(new Color(241, 245, 249));
        JPanel top = new JPanel(new BorderLayout());
        top.add(buildHeader(), BorderLayout.NORTH);
        top.add(buildDatabaseBar(), BorderLayout.SOUTH);
        root.add(top, BorderLayout.NORTH);
        JSplitPane body = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                buildEditor(), buildWorkspace());
        body.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
        body.setResizeWeight(0);
        body.setDividerLocation(380);
        body.setContinuousLayout(true);
        root.add(body, BorderLayout.CENTER);
        root.add(buildStatus(), BorderLayout.SOUTH);
        setContentPane(root);
        addWindowListener(new WindowAdapter() {
            /**
             * windowClosing routes the title-bar close action through Exit.
             *
             * @param event the user's request to close this window
             */
            @Override public void windowClosing(WindowEvent event) { runAction(() -> requestExit()); }
        });
        databasePath.setText(suggestSamplePath());
        refreshTable();
        resetScore();
        report("Ready. Browse to pokemon_builds.db, then choose Connect. Successful changes save immediately.", false);
    }

    /**
     * buildHeader creates the application identity and live collection summary.
     *
     * @return the header panel
     */
    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(20, 0));
        header.setBackground(new Color(20, 36, 57));
        header.setBorder(BorderFactory.createEmptyBorder(16, 22, 16, 22));
        JPanel title = new JPanel(new GridLayout(2, 1, 0, 4));
        title.setOpaque(false);
        JLabel name = new JLabel("Pokemon Build DMS");
        name.setFont(new Font("SansSerif", Font.BOLD, 25));
        name.setForeground(Color.WHITE);
        JLabel subtitle = new JLabel("Build collection  /  Team planning");
        subtitle.setForeground(new Color(165, 208, 232));
        title.add(name);
        title.add(subtitle);
        counts.setName("collectionCounts");
        counts.setForeground(Color.WHITE);
        counts.setFont(counts.getFont().deriveFont(Font.BOLD, 14f));
        header.add(title, BorderLayout.WEST);
        header.add(counts, BorderLayout.EAST);
        return header;
    }

    /**
     * buildDatabaseBar provides the user-supplied database location and connection controls.
     *
     * @return the database connection controls
     */
    private JPanel buildDatabaseBar() {
        JPanel panel = new JPanel(new BorderLayout(9, 0));
        panel.setBorder(BorderFactory.createEmptyBorder(12, 14, 0, 14));
        panel.setOpaque(false);
        JLabel label = new JLabel("SQLite database");
        label.setLabelFor(databasePath);
        databasePath.setName("databasePath");
        databasePath.setToolTipText("Enter the path to an existing SQLite database containing pokemon_builds.");
        databasePath.addActionListener(event -> runAction(() -> openDatabase()));
        panel.add(label, BorderLayout.WEST);
        panel.add(databasePath, BorderLayout.CENTER);
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 7, 0));
        actions.setOpaque(false);
        actions.add(button("Browse...", "browseDatabase", () -> browseDatabase(), false));
        actions.add(button("Connect", "connectDatabase", () -> openDatabase(), true));
        panel.add(actions, BorderLayout.EAST);
        return panel;
    }

    /**
     * buildEditor combines the nine-field form and explicit save actions.
     *
     * @return the editor panel
     */
    private JPanel buildEditor() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setMinimumSize(new Dimension(355, 400));
        panel.setBackground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(form);
        scroll.setBorder(null);
        panel.add(scroll, BorderLayout.CENTER);
        JPanel bottom = new JPanel(new BorderLayout(0, 9));
        bottom.setBackground(Color.WHITE);
        bottom.setBorder(BorderFactory.createEmptyBorder(2, 16, 14, 16));
        JPanel buttons = new JPanel(new GridLayout(1, 2, 8, 0));
        buttons.setOpaque(false);
        buttons.add(button("Add build", "addBuild", () -> addBuild(), true));
        buttons.add(button("Update build", "updateBuild", () -> updateBuild(), false));
        bottom.add(buttons, BorderLayout.NORTH);
        bottom.add(button("New / clear form", "newBuild", () -> newBuild(), false), BorderLayout.CENTER);
        JLabel hint = new JLabel("Select a row or find an ID before updating.");
        hint.setForeground(new Color(85, 100, 119));
        hint.setFont(hint.getFont().deriveFont(11f));
        bottom.add(hint, BorderLayout.SOUTH);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }

    /**
     * buildWorkspace organizes table controls above the calculation and database activity log.
     *
     * @return a table and reporting panel
     */
    private JPanel buildWorkspace() {
        JPanel workspace = new JPanel(new BorderLayout(0, 10));
        workspace.setOpaque(false);
        workspace.setMinimumSize(new Dimension(700, 400));
        JPanel records = new JPanel(new BorderLayout(0, 9));
        records.setBackground(Color.WHITE);
        records.setBorder(BorderFactory.createEmptyBorder(12, 12, 10, 12));
        JPanel controls = new JPanel(new GridLayout(2, 1, 0, 9));
        controls.setOpaque(false);
        controls.add(buildFilters());
        JPanel find = new JPanel(new FlowLayout(FlowLayout.LEFT, 7, 0));
        find.setOpaque(false);
        JLabel idLabel = new JLabel("Build ID");
        idLabel.setLabelFor(targetId);
        targetId.setName("targetId");
        targetId.addActionListener(event -> runAction(() -> findBuild()));
        find.add(idLabel);
        find.add(targetId);
        find.add(button("Find ID", "findBuild", () -> findBuild(), false));
        find.add(button("Remove ID", "removeBuild", () -> removeBuild(), false));
        find.add(button("Display all", "displayAll", () -> displayAll(), false));
        find.add(visibleCount);
        controls.add(find);
        records.add(controls, BorderLayout.NORTH);
        table.setName("buildTable");
        table.setRowSorter(sorter);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(29);
        table.setFont(new Font("SansSerif", Font.PLAIN, 13));
        table.setFillsViewportHeight(true);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(8, 0));
        table.setSelectionBackground(new Color(215, 233, 251));
        table.setSelectionForeground(new Color(20, 36, 57));
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        table.getTableHeader().setReorderingAllowed(false);
        int[] widths = {54, 135, 78, 78, 78, 48, 70, 44, 100};
        for (int index = 0; index < widths.length; index++) {
            table.getColumnModel().getColumn(index).setPreferredWidth(widths[index]);
        }
        table.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && !refreshing) { runAction(() -> selectTableBuild()); }
        });
        JScrollPane tableScroll = new JScrollPane(table);
        tableScroll.setPreferredSize(new Dimension(800, 265));
        records.add(tableScroll, BorderLayout.CENTER);
        reports.setName("reports");
        scoreReport.setName("scoreReport");
        configureReport(scoreReport);
        configureReport(activity);
        activity.setName("activityReport");
        JPanel scoring = new JPanel(new BorderLayout(12, 0));
        scoring.setBackground(Color.WHITE);
        scoring.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        JPanel scoreActions = new JPanel(new BorderLayout(0, 10));
        scoreActions.setOpaque(false);
        scoreValue.setName("scoreValue");
        scoreValue.setFont(new Font("SansSerif", Font.BOLD, 23));
        scoreValue.setForeground(new Color(24, 92, 160));
        scoreActions.add(scoreValue, BorderLayout.NORTH);
        scoreActions.add(button("Calculate score", "calculateScore", () -> calculateScore(), true), BorderLayout.CENTER);
        JLabel note = new JLabel("Uses all selected builds");
        note.setFont(note.getFont().deriveFont(11f));
        scoreActions.add(note, BorderLayout.SOUTH);
        scoring.add(scoreActions, BorderLayout.WEST);
        scoring.add(new JScrollPane(scoreReport), BorderLayout.CENTER);
        reports.addTab("Team readiness", scoring);
        reports.addTab("Activity / database report", new JScrollPane(activity));
        JSplitPane vertical = new JSplitPane(JSplitPane.VERTICAL_SPLIT, records, reports);
        vertical.setBorder(null);
        vertical.setResizeWeight(0.68);
        vertical.setDividerLocation(355);
        vertical.addComponentListener(new ComponentAdapter() {
            /**
             * componentResized keeps the score controls usable on shorter displays.
             *
             * @param event workspace resize notification
             */
            @Override public void componentResized(ComponentEvent event) {
                vertical.setDividerLocation(0.64);
            }
        });
        vertical.setContinuousLayout(true);
        workspace.add(vertical, BorderLayout.CENTER);
        return workspace;
    }

    /**
     * buildFilters creates literal name search and fixed type/role filters.
     *
     * @return filter controls
     */
    private JPanel buildFilters() {
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 7, 0));
        filters.setOpaque(false);
        search.setName("searchSpecies");
        search.setToolTipText("Species name contains this text; search treats punctuation literally.");
        JLabel label = new JLabel("Search");
        label.setLabelFor(search);
        filters.add(label);
        filters.add(search);
        typeFilter.addItem("All types");
        for (String type : validator.getTypes()) { typeFilter.addItem(type); }
        roleFilter.addItem("All roles");
        for (String role : validator.getRoles()) { roleFilter.addItem(role); }
        typeFilter.setName("typeFilter");
        roleFilter.setName("roleFilter");
        typeFilter.setToolTipText("Match either primary or secondary type");
        roleFilter.setToolTipText("Match the build role");
        teamOnly.setName("teamOnly");
        teamOnly.setOpaque(false);
        filters.add(typeFilter);
        filters.add(roleFilter);
        filters.add(teamOnly);
        typeFilter.addActionListener(event -> applyFilters());
        roleFilter.addActionListener(event -> applyFilters());
        teamOnly.addActionListener(event -> applyFilters());
        search.getDocument().addDocumentListener(new DocumentListener() {
            /**
             * insertUpdate refreshes matches after text is added.
             *
             * @param event document insertion notification
             */
            @Override public void insertUpdate(DocumentEvent event) { applyFilters(); }
            /**
             * removeUpdate refreshes matches after text is removed.
             *
             * @param event document removal notification
             */
            @Override public void removeUpdate(DocumentEvent event) { applyFilters(); }
            /**
             * changedUpdate handles styled-document changes consistently.
             *
             * @param event document formatting notification
             */
            @Override public void changedUpdate(DocumentEvent event) { applyFilters(); }
        });
        return filters;
    }

    /**
     * buildStatus presents persistent feedback and a clearly labeled Exit button.
     *
     * @return the bottom status panel
     */
    private JPanel buildStatus() {
        JPanel panel = new JPanel(new BorderLayout(16, 0));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 18, 10, 18));
        status.setName("status");
        status.setEditable(false);
        status.setFocusable(false);
        status.setLineWrap(true);
        status.setWrapStyleWord(true);
        status.setFont(new Font("SansSerif", Font.PLAIN, 13));
        panel.add(status, BorderLayout.CENTER);
        panel.add(button("Exit", "exit", () -> requestExit(), false), BorderLayout.EAST);
        return panel;
    }

    /**
     * buildMenu exposes only valid actions through graphical menu items.
     *
     * @return the complete CRUD and database menu
     */
    private JMenuBar buildMenu() {
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        addMenuItem(file, "Browse for SQLite database...", () -> browseDatabase());
        addMenuItem(file, "Connect to SQLite database", () -> openDatabase());
        file.addSeparator();
        addMenuItem(file, "Exit", () -> requestExit());
        JMenu records = new JMenu("Builds");
        addMenuItem(records, "New / clear form", () -> newBuild());
        addMenuItem(records, "Add build", () -> addBuild());
        addMenuItem(records, "Find build by ID", () -> findBuild());
        addMenuItem(records, "Update build", () -> updateBuild());
        addMenuItem(records, "Remove build by ID", () -> removeBuild());
        addMenuItem(records, "Display all builds", () -> displayAll());
        JMenu team = new JMenu("Team");
        addMenuItem(team, "Calculate readiness score", () -> calculateScore());
        bar.add(file);
        bar.add(records);
        bar.add(team);
        return bar;
    }

    /**
     * addMenuItem binds a menu choice to the same workflow used by its button.
     *
     * @param menu owning menu
     * @param label visible choice
     * @param action operation selected by the user
     */
    private void addMenuItem(JMenu menu, String label, Runnable action) {
        JMenuItem item = new JMenuItem(label);
        item.addActionListener(event -> runAction(action));
        menu.add(item);
    }

    /**
     * button creates a named, accessible action control with consistent spacing.
     *
     * @param label visible action
     * @param name stable component identifier
     * @param action operation invoked by a click
     * @param primary whether to use the blue primary-action style
     * @return the configured button
     */
    private JButton button(String label, String name, Runnable action, boolean primary) {
        JButton button = new JButton(label);
        button.setName(name);
        button.setMargin(new java.awt.Insets(7, 11, 7, 11));
        button.addActionListener(event -> runAction(action));
        if (primary) {
            button.setBackground(new Color(27, 99, 173));
            button.setForeground(Color.WHITE);
            button.setOpaque(true);
        }
        return button;
    }

    /**
     * configureReport gives a report readable, selectable, wrapped text.
     *
     * @param area destination report area
     */
    private void configureReport(JTextArea area) {
        area.setEditable(false);
        area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setMargin(new java.awt.Insets(10, 10, 10, 10));
        area.setFont(new Font("SansSerif", Font.PLAIN, 12));
    }

    /**
     * suggestSamplePath suggests a portable nearby sample location; the user still chooses Connect.
     *
     * @return a readable sample path when found, otherwise the editable pokemon_builds.db name
     */
    private String suggestSamplePath() {
        try {
            Path working = Paths.get("pokemon_builds.db").toAbsolutePath();
            if (Files.isRegularFile(working)) { return working.toString(); }
            Path location = Paths.get(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            Path folder = Files.isDirectory(location) ? location : location.getParent();
            if (folder != null && Files.isRegularFile(folder.resolve("pokemon_builds.db"))) {
                return folder.resolve("pokemon_builds.db").toString();
            }
            if (folder != null && folder.getParent() != null
                    && Files.isRegularFile(folder.getParent().resolve("pokemon_builds.db"))) {
                return folder.getParent().resolve("pokemon_builds.db").toString();
            }
        } catch (Exception ex) {
            // The user can still browse when a launch location cannot be resolved.
        }
        return "pokemon_builds.db";
    }

    /**
     * browseDatabase lets the user select an existing database without typing a location.
     */
    private void browseDatabase() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose an existing SQLite database");
        chooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("SQLite databases (*.db, *.sqlite, *.sqlite3)", "db", "sqlite", "sqlite3"));
        chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            databasePath.setText(chooser.getSelectedFile().getAbsolutePath());
            report("Database selected. Choose Connect to read its records.", false);
        }
    }

    /**
     * openDatabase validates the supplied file before replacing the active connection.
     */
    private void openDatabase() {
        if (!repository.openDatabase(databasePath.getText())) {
            report(repository.getLastError(), true);
            return;
        }
        databasePath.setText(repository.getDatabasePath());
        clearFilters();
        refreshTable();
        clearEditor();
        resetScore();
        report("Connected to " + repository.getDatabasePath() + ". Loaded " + model.getRowCount()
                + " build(s). Changes save immediately to this database.", false);
    }

    /**
     * runAction keeps recoverable database failures inside the current GUI session.
     *
     * @param action requested menu, button, or keyboard workflow
     */
    private void runAction(Runnable action) {
        try { action.run(); }
        catch (DatabaseAccessException | SecurityException ex) { report(ex.getMessage(), true); }
    }

    /**
     * addBuild commits the complete form only when every validation rule passes.
     */
    private void addBuild() {
        try {
            PokemonBuild build = form.readBuild();
            if (!repository.addBuild(build)) { report(repository.getLastError(), true); return; }
            changed(build.getBuildId());
            report("Saved to database: added build #" + build.getBuildId() + " (" + build.getSpeciesName() + ").", false);
        } catch (IllegalArgumentException ex) { report(ex.getMessage(), true); }
    }

    /**
     * updateBuild uses the original selected ID while allowing all nine edits.
     */
    private void updateBuild() {
        if (editingId == null) { report("Select a table row or use Find ID before updating.", true); return; }
        try {
            PokemonBuild replacement = form.readBuild();
            int original = editingId;
            if (!repository.updateBuild(original, replacement)) { report(repository.getLastError(), true); return; }
            changed(replacement.getBuildId());
            report("Saved to database: updated build #" + original + " as #" + replacement.getBuildId() + ". All fields were validated.", false);
        } catch (IllegalArgumentException ex) { report(ex.getMessage(), true); }
    }

    /**
     * findBuild retrieves the requested ID and loads its current editable values.
     */
    private void findBuild() {
        Optional<Integer> id = readTargetId();
        if (!id.isPresent()) { return; }
        Optional<PokemonBuild> build = repository.findBuildById(id.get());
        if (!build.isPresent()) { report("Build ID " + id.get() + " was not found.", true); return; }
        clearFilters();
        refreshTable();
        selectId(id.get());
        report("Loaded build #" + id.get() + " into the form. Change any fields, then choose Update build.", false);
    }

    /**
     * removeBuild confirms the exact record before deleting it by ID.
     */
    private void removeBuild() {
        Optional<Integer> id = readTargetId();
        if (!id.isPresent()) { return; }
        Optional<PokemonBuild> build = repository.findBuildById(id.get());
        if (!build.isPresent()) { report("Build ID " + id.get() + " was not found. Nothing was removed.", true); return; }
        if (!confirm("Remove build", "Remove #" + id.get() + " (" + build.get().getSpeciesName() + ")?")) {
            report("Removal canceled. The record is still stored.", false); return;
        }
        if (!repository.removeBuild(id.get())) { report(repository.getLastError(), true); return; }
        resetScore();
        refreshTable();
        clearEditor();
        report("Saved to database: removed build #" + id.get() + ". The table now shows the remaining records.", false);
    }

    /**
     * readTargetId validates the separate lookup/deletion identifier.
     *
     * @return a positive ID, or empty after a visible error message
     */
    private Optional<Integer> readTargetId() {
        Optional<Integer> id = validator.parseIntInRange(targetId.getText(), 1, Integer.MAX_VALUE);
        if (!id.isPresent()) { report("Enter a positive whole-number Build ID beside Find ID / Remove ID.", true); }
        return id;
    }

    /**
     * selectTableBuild resolves view sorting before loading the chosen record.
     */
    private void selectTableBuild() {
        int row = table.getSelectedRow();
        if (row < 0) { return; }
        PokemonBuild build = model.getBuild(table.convertRowIndexToModel(row));
        editingId = build.getBuildId();
        targetId.setText(Integer.toString(editingId));
        form.showBuild(build);
    }

    /**
     * selectId highlights an exact stored identifier after adding or editing.
     *
     * @param id record ID that should become the active editor target
     */
    private void selectId(int id) {
        for (int row = 0; row < model.getRowCount(); row++) {
            if (model.getBuild(row).getBuildId() == id) {
                int viewRow = table.convertRowIndexToView(row);
                if (viewRow >= 0) {
                    table.setRowSelectionInterval(viewRow, viewRow);
                    table.scrollRectToVisible(table.getCellRect(viewRow, 0, true));
                    selectTableBuild();
                }
                return;
            }
        }
    }

    /**
     * changed refreshes the collection and invalidates a previously shown score.
     *
     * @param id saved record to select in the refreshed display
     */
    private void changed(int id) {
        resetScore();
        clearFilters();
        refreshTable();
        selectId(id);
    }

    /**
     * newBuild abandons the current draft without modifying stored data.
     */
    private void newBuild() {
        clearEditor();
        report("New build form ready. Complete the fields, then choose Add build.", false);
    }

    /**
     * clearEditor clears the selected record and suggests the first unused ID.
     */
    private void clearEditor() {
        refreshing = true;
        table.clearSelection();
        refreshing = false;
        editingId = null;
        targetId.setText("");
        int next = 1;
        while (repository.containsId(next) && next < Integer.MAX_VALUE) { next++; }
        form.reset(next);
    }

    /**
     * displayAll removes filters and redraws every current stored record.
     */
    private void displayAll() {
        clearFilters();
        resetScore();
        refreshTable();
        report(repository.count() == 0 ? "No builds stored. Connect to a database or add a build."
                : "Displaying all " + repository.count() + " stored build(s).", false);
    }

    /**
     * clearFilters restores the unfiltered table without changing saved data.
     */
    private void clearFilters() {
        refreshing = true;
        search.setText("");
        typeFilter.setSelectedIndex(0);
        roleFilter.setSelectedIndex(0);
        teamOnly.setSelected(false);
        refreshing = false;
        applyFilters();
    }

    /**
     * applyFilters matches literal input against the displayed record snapshot.
     */
    private void applyFilters() {
        if (refreshing) { return; }
        final String query = search.getText().trim().toLowerCase(Locale.ROOT);
        final String type = typeFilter.getSelectedIndex() > 0 ? (String) typeFilter.getSelectedItem() : "";
        final String role = roleFilter.getSelectedIndex() > 0 ? (String) roleFilter.getSelectedItem() : "";
        final boolean selectedOnly = teamOnly.isSelected();
        sorter.setRowFilter(new RowFilter<BuildTableModel, Integer>() {
            /**
             * include combines name, either-type, role, and selected-team filters.
             *
             * @param entry model row being considered by the sorter
             * @return true when every active filter matches this record
             */
            @Override public boolean include(Entry<? extends BuildTableModel, ? extends Integer> entry) {
                PokemonBuild build = model.getBuild(entry.getIdentifier());
                return build.getSpeciesName().toLowerCase(Locale.ROOT).contains(query)
                        && (type.isEmpty() || type.equals(build.getPrimaryType()) || type.equals(build.getSecondaryType()))
                        && (role.isEmpty() || role.equals(build.getRole()))
                        && (!selectedOnly || build.isSelectedForTeam());
            }
        });
        visibleCount.setText(table.getRowCount() + " shown");
    }

    /**
     * refreshTable obtains fresh independent copies after any collection change.
     */
    private void refreshTable() {
        List<PokemonBuild> snapshot = repository.getAllBuilds();
        refreshing = true;
        model.setBuilds(snapshot);
        refreshing = false;
        applyFilters();
        int selected = 0;
        for (PokemonBuild build : snapshot) { if (build.isSelectedForTeam()) { selected++; } }
        counts.setText(snapshot.size() + " builds   |   " + selected + " / 6 team slots");
    }

    /**
     * calculateScore uses the entire selected team even when table filters hide it.
     */
    private void calculateScore() {
        reports.setSelectedIndex(0);
        try {
            List<PokemonBuild> builds = repository.getAllBuilds();
            double score = calculator.calculateScore(builds);
            scoreValue.setText(String.format(Locale.US, "%.2f / 100", score));
            scoreReport.setText(calculator.buildExplanation(builds)
                    + "\nUsage values are sample data. This score summarizes stored attributes; it is not a battle prediction.");
            scoreReport.setCaretPosition(0);
            report("Calculated team readiness from " + repository.getSelectedBuilds().size() + " selected build(s).", false);
        } catch (IllegalArgumentException ex) {
            scoreValue.setText("-- / 100");
            scoreReport.setText(ex.getMessage());
            report(ex.getMessage(), true);
        }
    }

    /**
     * resetScore removes stale arithmetic whenever its source data changes.
     */
    private void resetScore() {
        scoreValue.setText("-- / 100");
        scoreReport.setText("Select 1 to 6 builds using the form, then choose Calculate score.\n\n"
                + "Score = (Avg BST / 720 x 40) + (Distinct types / 18 x 25)\n"
                + "+ (Roles, capped at 4 / 4 x 20) + (Avg usage / 100 x 15).\n\n"
                + "Successful changes save immediately. Display all refreshes database rows.\n"
                + "Reconnect to the same database after reopening to continue working.");
    }

    /**
     * report displays persistent feedback and keeps a selectable action history.
     *
     * @param message human-readable outcome or input correction
     * @param error whether the operation was rejected
     */
    private void report(String message, boolean error) {
        status.setText((error ? "Please correct: " : "") + message);
        status.setForeground(error ? new Color(164, 37, 42) : new Color(37, 64, 83));
        activity.append((error ? "ERROR: " : "OK: ") + message + "\n");
        activity.setCaretPosition(activity.getDocument().getLength());
    }

    /**
     * confirm lets the user explicitly approve deletion or application exit.
     *
     * @param title dialog caption
     * @param message exact consequence of the pending action
     * @return true only when the user chooses Yes
     */
    protected boolean confirm(String title, String message) {
        return JOptionPane.showConfirmDialog(this, message, title,
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION;
    }

    /**
     * requestExit confirms an explicit exit and closes the database connection.
     */
    private void requestExit() {
        String message = "Exit Pokemon Build DMS? All successful changes are already saved to the database.";
        if (confirm("Exit application", message)) { repository.close(); dispose(); }
        else { report("Exit canceled. You can continue working.", false); }
    }
}
