package dms;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * BuildTableModel exposes nine typed, read-only columns to the Swing table.
 *
 * <p>Displayed rows are copies, so selecting or sorting the table cannot change
 * the database. The editor and repository perform validated writes instead.
 * Row arguments use model indexes; callers must convert sorted view indexes
 * before accessing a record. Update this model on Swing's event dispatch thread.</p>
 *
 * <p>Class: BuildTableModel. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class BuildTableModel extends AbstractTableModel {
    /**
     * BuildTableModel starts with nine columns and no displayed records.
     */
    public BuildTableModel() { }

    /**
     * Stable display order for the nine stored attributes.
     */
    private final String[] columns = {"ID", "Species", "Primary", "Secondary", "Role",
            "BST", "Usage %", "Team", "Last updated"};
    /**
     * Copied display snapshot, separate from repository storage.
     */
    private final List<PokemonBuild> rows = new ArrayList<PokemonBuild>();

    /**
     * setBuilds replaces the displayed snapshot with independent record copies.
     *
     * @param builds validated records to display
     */
    public void setBuilds(List<PokemonBuild> builds) {
        rows.clear();
        for (PokemonBuild build : builds) { rows.add(build.copy()); }
        fireTableDataChanged();
    }

    /**
     * getBuild retrieves a record by model row, independent of visual sorting.
     *
     * @param row zero-based model row
     * @return an independent record copy
     */
    public PokemonBuild getBuild(int row) { return rows.get(row).copy(); }

    /**
     * getRowCount reports the number of displayed records.
     *
     * @return snapshot row count
     */
    @Override public int getRowCount() { return rows.size(); }

    /**
     * getColumnCount reports the nine planned attribute columns.
     *
     * @return attribute count
     */
    @Override public int getColumnCount() { return columns.length; }

    /**
     * getColumnName supplies the readable heading for one column.
     *
     * @param column zero-based column index
     * @return visible column heading
     */
    @Override public String getColumnName(int column) { return columns[column]; }

    /**
     * getColumnClass enables numeric/date sorting and boolean check marks.
     *
     * @param column zero-based column index
     * @return the value type of that column
     */
    @Override public Class<?> getColumnClass(int column) {
        switch (column) {
            case 0: case 5: return Integer.class;
            case 6: return Double.class;
            case 7: return Boolean.class;
            case 8: return LocalDate.class;
            default: return String.class;
        }
    }

    /**
     * getValueAt supplies an attribute without exposing the stored object.
     *
     * @param row zero-based model row
     * @param column zero-based attribute column
     * @return typed display value
     */
    @Override public Object getValueAt(int row, int column) {
        PokemonBuild build = rows.get(row);
        switch (column) {
            case 0: return build.getBuildId();
            case 1: return build.getSpeciesName();
            case 2: return build.getPrimaryType();
            case 3: return build.getSecondaryType().isEmpty() ? "None" : build.getSecondaryType();
            case 4: return build.getRole();
            case 5: return build.getBaseStatTotal();
            case 6: return build.getUsageRate();
            case 7: return build.isSelectedForTeam();
            case 8: return build.getLastUpdated();
            default: throw new IndexOutOfBoundsException("Unknown build attribute.");
        }
    }

    /**
     * isCellEditable keeps every mutation inside the validated form workflow.
     *
     * @param row table row
     * @param column table column
     * @return false for every cell
     */
    @Override public boolean isCellEditable(int row, int column) { return false; }
}
