package dms;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Main launches the graphical Pokemon Build Management System.
 *
 * <p>The application solves the problem of organizing nine-field Pokemon builds:
 * users connect to an existing SQLite database, display and edit its records,
 * manage a team of up to six builds, and calculate a weighted readiness score.
 * {@link PokemonBuildFrame} presents every production interaction through Swing;
 * {@link SqliteBuildRepository} commits accepted changes to the selected file.
 * Startup runs on Swing's event dispatch thread.</p>
 *
 * <p>Class: Main. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class Main {
    /**
     * Main creates a launcher; main(String[]) schedules the graphical startup.
     */
    public Main() { }

    /**
     * main schedules application startup on Swing's event dispatch thread.
     *
     * @param args command-line arguments; not needed for the graphical interface
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().launch());
    }

    /**
     * launch applies a consistent look and constructs the existing logic layers.
     */
    private void launch() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception ex) {
            // Swing's default look remains usable if a requested look is unavailable.
        }
        UIManager.put("Button.font", new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13));
        UIManager.put("Label.font", new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13));
        UIManager.put("TextField.font", new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13));
        UIManager.put("ComboBox.font", new java.awt.Font("SansSerif", java.awt.Font.PLAIN, 13));
        BuildValidator validator = new BuildValidator();
        SqliteBuildRepository repository = new SqliteBuildRepository(validator);
        new PokemonBuildFrame(validator, repository,
                new TeamReadinessCalculator(validator)).setVisible(true);
    }
}
