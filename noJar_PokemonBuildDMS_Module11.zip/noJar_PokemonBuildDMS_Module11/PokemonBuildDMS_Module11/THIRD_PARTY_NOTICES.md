# Bundled dependencies

Runtime libraries (bundled inside the executable JAR and supplied separately in `lib`):

- Xerial SQLite JDBC 3.50.3.0. Apache License 2.0 and BSD notices. https://github.com/xerial/sqlite-jdbc
- SLF4J API 2.0.17 and SLF4J NOP 2.0.17. MIT License. https://www.slf4j.org/license.html

Test-only libraries (excluded from the executable JAR):

- JUnit 4.13.2. Eclipse Public License 1.0. https://junit.org/junit4/
- Hamcrest Core 1.3. BSD License. https://hamcrest.org/

SQLite itself is in the public domain: https://www.sqlite.org/copyright.html

The runtime versions above are pinned for reproducible builds; they are not a claim to be the latest release. The JDBC JAR includes native SQLite libraries for Windows, macOS, and Linux. Original dependency license/notice resources are retained under `licenses` where included by their publishers.
