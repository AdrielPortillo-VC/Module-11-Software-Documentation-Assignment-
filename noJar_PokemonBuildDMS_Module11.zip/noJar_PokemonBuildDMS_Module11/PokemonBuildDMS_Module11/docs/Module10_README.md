# Pokemon Build DMS - Module 10 / Phase 4

Adriel Portillo Perez | CEN 3024C | November 9, 2026

This phase adds SQLite 3 persistence to the existing Phase 3 Swing application. Users select an existing database through the GUI, view its records, add builds, edit all nine fields (including ID), remove records, and calculate the Team Readiness Score. Successful changes commit immediately and survive reopening.

## Start in IntelliJ

1. Extract the entire ZIP. Open the `PokemonBuildDMS_Module10` folder containing `.idea`, `src`, `lib`, `database`, and `PokemonBuildDMS.iml`.
2. In **File > Project Structure > Project**, choose your installed JDK. The supplied project names JDK 27 to match Adriel's setup; select your installed JDK if IntelliJ reports it missing. Application source targets Java 8.
3. Run the supplied **PokemonBuildDMS** configuration or the green Run arrow in `src/dms/Main.java`.
4. In the application, use **Browse...** to select the extracted `pokemon_builds.db`, then click **Connect**. You can also type its absolute or relative path. A suggested nearby path is a convenience; no database is opened until you choose Connect.
5. The table displays 20 records, with five team members selected. **Calculate score** initially returns **64.45 / 100**.

The `lib` folder and IntelliJ module already include Xerial SQLite JDBC and its SLF4J dependencies. JUnit and Hamcrest are test-only. No Maven download, database server, username, or password is required.

If your IntelliJ installation does not load the supplied library entries, use **File > Project Structure > Modules > Dependencies > + > JARs or directories** and select the three runtime JARs in `lib`. Add JUnit and Hamcrest with Test scope if running the tests. SQL Helper can be used for viewing the database, but the application does not depend on that plugin.

## Run the supplied executable JAR

On Windows, double-click `run.bat`. Alternatively, from the extracted project folder:

```text
java -jar dist/PokemonBuildDMS_Module10.jar
```

On macOS/Linux, run `sh run.sh`. A desktop Java runtime 8 or newer is needed. The complete application JAR bundles SQLite JDBC, native database libraries for Windows/macOS/Linux, and the required logging libraries. It works without the separate `lib` folder at runtime. Keep a writable copy of `pokemon_builds.db` wherever you prefer and supply that location through the GUI. Extract files before running them; do not run from inside the ZIP.

SQLiteStudio or IntelliJ's database viewer is useful for the required demonstration. Installing the SQLite command-line program is optional for running this application because the JDBC library contains the SQLite engine. SQLite 3 database files work with the bundled driver.

## Use the application

- **Connect:** type or browse to an existing SQLite file. The application checks the table, columns, all rows, team count, and database write access. Blank, missing, directory, non-SQLite, incompatible-schema, malformed-row, and locked-file errors appear in the GUI. A failed connection keeps the previous database active. Opening a different database replaces the displayed collection; it does not merge the old rows.
- **Display all:** query the connected database again, remove filters, and show all nine columns. It also clears a prior score so external database changes cannot leave a misleading calculation visible.
- **Add build:** choose **New / clear form**, complete the fields, and click **Add build**. A valid, unique record is inserted into SQLite and displayed immediately. Success is reported after commit.
- **Find ID / Update build:** select a row or find its ID. Find ID reads current database values. Edit any of the nine fields and click **Update build**. The original ID identifies the row even when you change the ID. Duplicate IDs or invalid fields reject the entire edit.
- **Remove ID:** find or enter an ID and click **Remove ID**. The confirmation names the record. Choosing Yes deletes it from the database and table. No, closing the confirmation, or a nonexistent ID leaves data unchanged.
- **Search/filter:** match a literal species-name fragment, either type, a role, and/or selected team status. Sorting and filters affect the displayed snapshot; they do not alter the saved team or custom calculation.
- **Calculate score:** query the saved records and evaluate the selected team. Select 1-6 builds. The GUI explains every weighted component. Successful edits clear a stale score until recalculation.
- **Exit:** the button, File > Exit, and title-bar X all ask for confirmation. Cancel keeps the application open. Successful changes are already saved before exit. Unsaved form drafts have not been committed.

Every application interaction and error message occurs in the GUI. No console input is required.

## Data and validation

`pokemon_builds.db` contains the same 20 illustrative records used in Phase 3, stored in `pokemon_builds`. The nine columns are:

| SQL column | Stored value |
| --- | --- |
| build_id | Positive, unique INTEGER primary key, up to 2147483647 |
| species_name | TEXT from the supported 26-species catalog |
| primary_type | TEXT from the 18 allowed types |
| secondary_type | An allowed type or empty TEXT for None; different from the primary type |
| role | Sweeper, Wall, Pivot, Support, Lead, or Other |
| base_stat_total | INTEGER from 1 to 720 |
| usage_rate | Finite number from 0 to 100 |
| selected_for_team | INTEGER 0 or 1; at most six selected rows |
| last_updated | Real YYYY-MM-DD date from 1900-01-01 through today |

Usage percentages are demonstration data, not current competitive usage statistics. The application retains the existing project's finite species catalog and validation rules. SQL CHECK constraints and triggers also reject invalid values and a seventh selection through an external database viewer. Loaded rows are validated before the connection is accepted; invalid data is reported rather than silently changing the supplied database.

```text
Score = (Average BST / 720 x 40)
      + (Distinct represented types / 18 x 25)
      + (min(Distinct roles, 4) / 4 x 20)
      + (Average usage / 100 x 15)
```

The initial five selected builds produce 64.45 / 100. The score is a summary of stored attributes and is not a prediction of battle results.

## View the same database in SQLiteStudio

1. Choose **Database > Add a database**, select the exact same file shown in the application's location field, and connect.
2. Open `pokemon_builds` and its **Data** tab, or execute:

```sql
SELECT * FROM pokemon_builds ORDER BY build_id;
```

3. After every application Add, Update, or Remove, refresh the Data tab or run the SELECT again. Do not leave an unfinished editing transaction open in the database viewer; it can lock the database.
4. Close and reopen the Java app, connect to that same database, and verify the saved changes remain.

SQLite is a file database: two separately copied `.db` files contain separate data. Ensure both tools open the same file.

## Re-create the sample database

The supplied populated `.db` is ready to use. The SQL scripts are also included for review or rebuilding a fresh demonstration copy:

```text
sqlite3 fresh_pokemon_builds.db ".read database/create_sample_database.sql"
```

Run this from the project root and choose a new, unused output filename. The script creates the table, validation triggers, and exactly 20 rows in a transaction. It does not drop or overwrite an existing table. `database/schema.sql` and `database/sample_data.sql` separate the schema and seed data. `data.txt` remains only for historical Phase 2 regression tests; Phase 4 does not load text files through the GUI.

## Implementation

`Main` launches only the database-connected GUI. `PokemonBuildFrame` handles presentation and actions; `BuildFormPanel`, `BuildTableModel`, `BuildValidator`, and `TeamReadinessCalculator` retain the prior form, display, validation, and arithmetic responsibilities. `SqliteBuildRepository` runs SELECT, prepared INSERT/UPDATE/DELETE, and transactions. Writes acquire a short immediate transaction so duplicate-ID and team-size checks remain consistent across connections. Failed writes roll back. `DatabaseAccessException` carries recoverable read failures back to GUI messages.

The Phase 1/2 memory repository, file loader, and console app remain solely for regression coverage. The production GUI uses `SqliteBuildRepository` directly and has no in-memory storage fallback. No personal database path is hardcoded.

## Build and tests

Use `build.bat` on Windows or `sh build.sh` on macOS/Linux to rebuild the bundled executable JAR. These scripts need a JDK with `java`, `javac`, and `jar` on PATH. They support JDK 8's source/target options and newer JDKs' `--release 8` option. IntelliJ also includes an artifact configuration; the scripts are the reproducible packaging route.

Run `run-tests.bat` or `sh run-tests.sh` on a desktop. The test suite includes the 30 retained Phase 2 tests, 24 SQLite integration tests, and 22 tests that exercise actual Swing controls against temporary SQLite databases. All tests work on isolated copies and do not change the submitted sample database. IntelliJ run configurations are supplied for DmsTests, DatabaseTests, and GuiTests. GUI tests need a graphical display; database and logic tests can run headlessly.

See `TEST_RESULTS.md` for validation evidence, `Module10_Recording_Guide.txt` for the rubric-ordered recording script and submission checklist, and `THIRD_PARTY_NOTICES.md` for dependencies.

## Submission items still requiring your actions

Submit the complete project ZIP, the populated SQLite database (also included in the ZIP), an updated GitHub repository link, and a cloud-hosted demonstration video link with sharing enabled. The video must show your face and screen and show the database viewer refreshing after CRUD operations. The full export includes the runnable JAR as an additional convenience.

The connected GitHub account exposed no accessible repositories during preparation, so this package has not been published. To keep phases separate, create `PokemonBuildDMS-Module10` in your own GitHub account and upload the extracted project contents, including source, tests, `.idea`, `.iml`, `lib`, `database`, the sample `.db`, documentation, and `dist` JAR. Omit generated `build`/`out` folders. Make sure the instructor can access the repository, and submit the repository URL; uploading only the ZIP is less useful for code review.
