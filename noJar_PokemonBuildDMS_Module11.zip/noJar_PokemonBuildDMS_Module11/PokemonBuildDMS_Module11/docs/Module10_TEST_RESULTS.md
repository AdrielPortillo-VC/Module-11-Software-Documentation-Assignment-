# Module 10 verification

Adriel Portillo Perez | CEN 3024C | November 9, 2026

**Result: 76 JUnit tests passed; zero failures.** The complete run is retained in `test-output.txt`.

| Suite | Tests | Scope |
| --- | ---: | --- |
| DmsTests | 30 | Retained Phase 2 logic, input validation, CRUD, text-file regression, and custom arithmetic |
| DatabaseTests | 24 | Actual SQLite connections, prepared CRUD, transactions, constraints, incoming-data validation, independent observers, and reopening |
| GuiTests | 22 | Actual Swing controls operating on isolated SQLite databases, including all-field edits, menus, errors, sorting/filtering, database refresh, calculation, and Exit cancellation |
| Total | 76 | All passed |

## Rubric coverage

| Rubric test | Verified behavior |
| --- | --- |
| 1. Display a Menu | Supported GUI menus and buttons are present. Bad inputs keep the window open. Exit and title-bar close honor confirmation/cancellation. |
| 2. Read Data | User-supplied paths; blank, missing, directory, NUL, non-database, wrong-schema, and malformed-row inputs rejected. Failed connection preserves prior data. Quoted paths and paths with spaces, punctuation, and Unicode tested. Switching databases replaces rather than merges rows. |
| 3. Display Data | Twenty sample records and all nine columns shown. Display all and Find ID obtain current database values, including edits and added rows from a second connection. |
| 4. Create Data | Form addition commits and is visible to an independent SQL connection and after reopening. Duplicate IDs, invalid fields, and a seventh team member rejected. |
| 5. Remove Data | Confirmation/cancellation and missing IDs handled. Confirmed deletion appears in the table, second connection, and after reopening. |
| 6. Update Data | All nine fields, including ID, update atomically. Duplicate replacement IDs and invalid fields preserve prior data. Correct sorted row updated. Second connection and reopening observe persisted edits. |
| 7. Custom Feature | Original sample score is 64.45 / 100. Calculation uses selected database rows, ignores display filters, rejects empty teams, and responds to external usage changes. |
| Comments | Class headers include name, course, date, class name, and purpose. Non-accessor methods have multiline purpose, argument, and return documentation. Main describes the whole project. Source audit found no missing required method comments. |

## Database failure and integrity checks

- A second connection sees committed additions, edits, and removals immediately.
- Closing and reconnecting preserves changes; no in-memory fallback is used.
- Duplicate-ID and team-size checks occur inside a write transaction. Rejected changes roll back, and a subsequent valid change succeeds.
- A competing immediate transaction causes a clear busy/locked error; the operation succeeds after releasing the lock.
- CHECK constraints reject invalid external values, including unsupported species/types/roles, bad IDs, fractional/out-of-range stats, invalid percentages, invalid Boolean flags, impossible dates, future dates, and NULL required data.
- SQL triggers reject a seventh selection through independent INSERT and UPDATE operations.
- A corrupted row is rejected both while opening a database and during later reads. GUI errors keep the window available.
- The untouched submitted sample has exactly 20 records, five selected builds, and `PRAGMA integrity_check` returns `ok`.
- Executing the supplied creation script against a new database creates exactly 20 records with integrity check `ok`.

## Packaged executable and visual review

The complete application JAR was exercised from a temporary folder containing only that JAR and a copied database, with the verification harness supplied separately. It loaded the production GUI and bundled SQLite driver/native engine, displayed 20 rows and nine columns, and calculated 64.45 / 100 without the project lib folder on its classpath.

Application classes use Java 8 class-file version 52. The executable includes the JDBC service registration and Windows x86_64 native library and excludes JUnit/Hamcrest classes. IntelliJ XML files parse successfully. Production GUI renders were visually reviewed at 1320 x 800 and 1140 x 720; the smaller view preserves access using scrolling. Screenshots are in `docs`.

Tests ran on Linux using OpenJDK 17.0.20 with a virtual graphical display and bundled Xerial SQLite JDBC 3.50.3.0. This environment did not execute the Windows batch scripts, IntelliJ itself, or a Java 8 runtime. Bytecode compatibility, project configuration, bundled Windows native resources, and batch-script paths were inspected; run the package on your Windows machine before recording.

## Submission status

The project export, executable JAR, populated SQLite database, SQL creation scripts, documentation, and recording guide are included. GitHub publishing remains for the user because the connected account exposed no accessible repositories. The user must record the required face-and-screen demonstration, refresh the database viewer during CRUD changes, and submit an accessible cloud video link.
