package dms;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * DatabaseTests verifies production SQLite operations against isolated fixture files.
 *
 * <p>Tests cover CRUD persistence, independent readers, reconnecting, rollback,
 * schema validation, SQL constraints, locking, defensive copies, and calculation
 * inputs. {@link TestDatabases} creates each fixture from the supplied SQL files;
 * the submitted sample database is never modified. These tests can run headlessly.</p>
 *
 * <p>Class: DatabaseTests. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class DatabaseTests {
    /**
     * DatabaseTests prepares fixture tracking; open() creates the per-test database.
     */
    public DatabaseTests() { }

    /**
     * Validation rules shared by test repositories.
     */
    private final BuildValidator validator = new BuildValidator();
    /**
     * Factory for independent schema and seed-data fixtures.
     */
    private final TestDatabases fixtures = new TestDatabases();
    /**
     * Test-owned paths deleted during cleanup.
     */
    private final List<Path> temporary = new ArrayList<Path>();
    /**
     * Active repository opened by the per-test setup method.
     */
    private SqliteBuildRepository repository;
    /**
     * Current populated fixture observed through separate connections.
     */
    private Path database;

    /**
     * open prepares a private populated database for each test.
     * @throws Exception if fixture creation or the test database connection fails
     */
    @Before public void open() throws Exception {
        database = fixture(true);
        repository = new SqliteBuildRepository(validator);
        assertTrue(repository.getLastError(), repository.openDatabase(database.toString()));
    }

    /**
     * close releases connections and deletes every test-owned fixture.
     * @throws Exception if a connection cannot close or a fixture file cannot be removed
     */
    @After public void close() throws Exception {
        if (repository != null) { repository.close(); }
        for (Path path : temporary) { Files.deleteIfExists(path); }
    }

    /**
     * fixture tracks a newly generated test database for cleanup.
     *
     * @param populated whether the fixture should hold sample rows
     * @return the test-owned file
     * @throws Exception if schema or seed initialization fails
     */
    private Path fixture(boolean populated) throws Exception {
        Path path = fixtures.create(populated); temporary.add(path); return path;
    }

    /**
     * build supplies a valid proposed record.
     *
     * @param id desired identifier
     * @param selected desired team flag
     * @return a complete nine-field Pokemon build
     */
    private PokemonBuild build(int id, boolean selected) {
        return new PokemonBuild(id, "Umbreon", "Dark", "", "Wall", 525, 20,
                selected, LocalDate.of(2026, 10, 13));
    }

    /**
     * scalar observes current data through a second independent connection.
     *
     * @param sql read-only aggregate query
     * @return the first integer result
     * @throws Exception if opening the observer or executing the aggregate query fails
     */
    private int scalar(String sql) throws Exception {
        try (Connection observer = fixtures.connect(database); Statement query = observer.createStatement();
             ResultSet rows = query.executeQuery(sql)) { assertTrue(rows.next()); return rows.getInt(1); }
    }

    /**
     * execute simulates a change made in an external database viewer.
     *
     * @param sql statement applied to the current fixture
     * @throws Exception if the independent SQL connection or statement fails
     */
    private void execute(String sql) throws Exception {
        try (Connection observer = fixtures.connect(database); Statement command = observer.createStatement()) { command.execute(sql); }
    }

    /**
     * sampleHasTwentyRowsAndNineFields checks the submitted data contract.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void sampleHasTwentyRowsAndNineFields() throws Exception {
        assertEquals(20, repository.count()); assertEquals(5, repository.getSelectedBuilds().size());
        assertEquals("101,Garchomp,Dragon,Ground,Sweeper,600,28.4,true,2026-10-13",
                repository.findBuildById(101).get().toCsvLine());
        assertEquals(20, scalar("SELECT COUNT(*) FROM pokemon_builds"));
    }

    /**
     * invalidLocationsPreserveConnection rejects blank, missing, directory, and NUL paths.
     */
    @Test public void invalidLocationsPreserveConnection() {
        Path missing = Paths.get(database.toString() + "-missing");
        for (String value : new String[] {null, "", " ", missing.toString(), ".", "\u0000", "jdbc:sqlite::memory:"}) {
            assertFalse(repository.openDatabase(value)); assertTrue(repository.getLastError().contains("Cannot open database"));
            assertEquals(20, repository.count()); assertEquals(database.toString(), repository.getDatabasePath());
        }
        assertFalse(Files.exists(missing));
    }

    /**
     * textAndCorruptFilesAreRejected rejects files which are not SQLite databases.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void textAndCorruptFilesAreRejected() throws Exception {
        Path path = Files.createTempFile("pokemon-bad-", ".db"); temporary.add(path);
        Files.write(path, "not a database".getBytes(StandardCharsets.UTF_8));
        assertFalse(repository.openDatabase(path.toString())); assertEquals(20, repository.count());
    }

    /**
     * missingTableAndWrongColumnsAreRejected validates the schema before switching.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void missingTableAndWrongColumnsAreRejected() throws Exception {
        Path path = Files.createTempFile("pokemon-schema-", ".db"); temporary.add(path);
        try (Connection other = fixtures.connect(path); Statement command = other.createStatement()) {
            command.execute("CREATE TABLE unrelated (id INTEGER)");
            assertFalse(repository.openDatabase(path.toString()));
            command.execute("CREATE TABLE pokemon_builds (build_id TEXT, species_name TEXT)");
            assertFalse(repository.openDatabase(path.toString()));
        }
        assertEquals(20, repository.count());
    }

    /**
     * quotedAndSpecialCharacterPathsWork verifies portable JDBC URI construction.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void quotedAndSpecialCharacterPathsWork() throws Exception {
        Path directory = Files.createTempDirectory("pokemon-path-");
        Path path = directory.resolve("Adriel #1 ? caf\u00e9.db");
        try {
            Files.copy(database, path, StandardCopyOption.REPLACE_EXISTING);
            assertTrue(repository.getLastError(), repository.openDatabase("\"" + path + "\""));
            assertEquals(20, repository.count()); repository.close();
        } finally { Files.deleteIfExists(path); Files.deleteIfExists(directory); }
    }

    /**
     * switchToEmptyDatabaseDoesNotMergeOldRows checks database identity boundaries.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void switchToEmptyDatabaseDoesNotMergeOldRows() throws Exception {
        Path empty = fixture(false); assertTrue(repository.openDatabase(empty.toString()));
        assertEquals(0, repository.count()); assertTrue(repository.addBuild(build(1, false)));
        assertTrue(repository.openDatabase(database.toString())); assertEquals(20, repository.count());
        assertFalse(repository.containsId(1));
    }

    /**
     * insertVisibleToSecondConnectionAndAfterReopen proves durable creation.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void insertVisibleToSecondConnectionAndAfterReopen() throws Exception {
        assertTrue(repository.addBuild(build(121, false)));
        assertEquals(1, scalar("SELECT COUNT(*) FROM pokemon_builds WHERE build_id=121"));
        repository.close(); assertTrue(repository.openDatabase(database.toString()));
        assertEquals(21, repository.count()); assertEquals("Umbreon", repository.findBuildById(121).get().getSpeciesName());
    }

    /**
     * duplicateInsertRollsBackWithoutReplacingRow rejects existing primary keys.
     */
    @Test public void duplicateInsertRollsBackWithoutReplacingRow() {
        String before = repository.findBuildById(101).get().toCsvLine();
        assertFalse(repository.addBuild(build(101, false))); assertTrue(repository.getLastError().contains("already exists"));
        assertEquals(before, repository.findBuildById(101).get().toCsvLine());
        assertTrue(repository.addBuild(build(121, false))); assertEquals(21, repository.count());
    }

    /**
     * updateAllNineFieldsPersistsAtomically checks every editable field including ID.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void updateAllNineFieldsPersistsAtomically() throws Exception {
        PokemonBuild edited = new PokemonBuild(121, "Umbreon", "Dark", "", "Other", 525, 30, false, LocalDate.of(2026, 10, 14));
        assertTrue(repository.updateBuild(101, edited)); assertFalse(repository.containsId(101));
        assertEquals(0, scalar("SELECT COUNT(*) FROM pokemon_builds WHERE build_id=101"));
        repository.close(); assertTrue(repository.openDatabase(database.toString()));
        assertEquals(edited.toCsvLine(), repository.findBuildById(121).get().toCsvLine());
        assertEquals(20, repository.count());
    }

    /**
     * duplicateUpdateLeavesEveryOldFieldUnchanged checks rollback on key collisions.
     */
    @Test public void duplicateUpdateLeavesEveryOldFieldUnchanged() {
        String a = repository.findBuildById(101).get().toCsvLine(), b = repository.findBuildById(102).get().toCsvLine();
        assertFalse(repository.updateBuild(101, build(102, false)));
        assertEquals(a, repository.findBuildById(101).get().toCsvLine());
        assertEquals(b, repository.findBuildById(102).get().toCsvLine());
    }

    /**
     * missingUpdateAndNullInputsAreRejected checks safe repository failure paths.
     */
    @Test public void missingUpdateAndNullInputsAreRejected() {
        assertFalse(repository.updateBuild(999, build(121, false))); assertFalse(repository.updateBuild(101, null));
        assertFalse(repository.addBuild(null)); assertEquals(20, repository.count());
    }

    /**
     * deleteVisibleToSecondConnectionAndAfterReopen proves durable removal.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void deleteVisibleToSecondConnectionAndAfterReopen() throws Exception {
        assertTrue(repository.removeBuild(101)); assertEquals(0, scalar("SELECT COUNT(*) FROM pokemon_builds WHERE build_id=101"));
        repository.close(); assertTrue(repository.openDatabase(database.toString()));
        assertFalse(repository.containsId(101)); assertFalse(repository.removeBuild(101)); assertEquals(19, repository.count());
    }

    /**
     * seventhSelectedInsertAndUpdateAreRejected enforces the team limit in both workflows.
     */
    @Test public void seventhSelectedInsertAndUpdateAreRejected() {
        assertTrue(repository.addBuild(build(121, true))); assertFalse(repository.addBuild(build(122, true)));
        PokemonBuild seventh = repository.findBuildById(106).get(); seventh.setSelectedForTeam(true);
        assertFalse(repository.updateBuild(106, seventh)); assertEquals(6, repository.getSelectedBuilds().size());
        PokemonBuild original = repository.findBuildById(101).get(); original.setBuildId(123);
        assertTrue(repository.updateBuild(101, original)); assertEquals(6, repository.getSelectedBuilds().size());
    }

    /**
     * calculationUsesSavedTeamAndExternalEdits checks the planned arithmetic against SQLite.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void calculationUsesSavedTeamAndExternalEdits() throws Exception {
        TeamReadinessCalculator calculator = new TeamReadinessCalculator(validator);
        double initial = calculator.calculateScore(repository.getAllBuilds());
        assertEquals(64.44777777777777, initial, 0.000001);
        execute("UPDATE pokemon_builds SET usage_rate=50 WHERE build_id=101");
        assertEquals(initial + (50 - 28.4) / 5 / 100 * 15, calculator.calculateScore(repository.getAllBuilds()), 0.000001);
    }

    /**
     * emptyTeamCalculationIsRejected checks the zero-selection boundary.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void emptyTeamCalculationIsRejected() throws Exception {
        execute("UPDATE pokemon_builds SET selected_for_team=0");
        try { new TeamReadinessCalculator(validator).calculateScore(repository.getAllBuilds()); fail("Expected empty-team rejection"); }
        catch (IllegalArgumentException expected) { assertTrue(expected.getMessage().contains("Select 1 to 6")); }
    }

    /**
     * externalChangesAreReadFresh checks that display data is never only a cached list.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void externalChangesAreReadFresh() throws Exception {
        execute("UPDATE pokemon_builds SET usage_rate=77.5 WHERE build_id=101");
        assertEquals(77.5, repository.findBuildById(101).get().getUsageRate(), 0);
        execute("DELETE FROM pokemon_builds WHERE build_id=102"); assertEquals(19, repository.count());
    }

    /**
     * independentWritesRespectTeamLimit checks two concurrent repository instances.
     */
    @Test public void independentWritesRespectTeamLimit() {
        try (SqliteBuildRepository other = new SqliteBuildRepository(validator)) {
            assertTrue(other.openDatabase(database.toString())); assertTrue(repository.addBuild(build(121, true)));
            assertFalse(other.addBuild(build(122, true))); assertEquals(6, other.getSelectedBuilds().size());
        }
    }

    /**
     * lockedDatabaseRejectsWriteThenRecovers verifies busy errors and usable recovery.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void lockedDatabaseRejectsWriteThenRecovers() throws Exception {
        try (Connection locker = fixtures.connect(database); Statement command = locker.createStatement()) {
            command.execute("BEGIN IMMEDIATE"); assertFalse(repository.addBuild(build(121, false)));
            assertTrue(repository.getLastError().contains("busy or locked")); command.execute("ROLLBACK");
        }
        assertFalse(repository.containsId(121)); assertTrue(repository.addBuild(build(121, false)));
    }

    /**
     * databaseCheckConstraintsRejectInvalidExternalInputs tests the SQL protection layer.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void databaseCheckConstraintsRejectInvalidExternalInputs() throws Exception {
        for (String assignment : new String[] {"build_id=0", "species_name=''", "species_name='ABDCE'", "primary_type='Fake'",
                "secondary_type='Dragon'", "role='Fake'", "base_stat_total=721", "base_stat_total=1.5", "usage_rate=101",
                "selected_for_team=2", "last_updated='2026-02-30'", "last_updated='2999-01-01'", "usage_rate=NULL"}) {
            try { execute("UPDATE pokemon_builds SET " + assignment + " WHERE build_id=101"); fail(assignment); }
            catch (SQLException expected) { assertNotNull(expected.getMessage()); }
        }
        assertEquals(20, repository.count());
    }

    /**
     * databaseTeamTriggersRejectExternalSeventhSelection tests SQL inserts and updates.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void databaseTeamTriggersRejectExternalSeventhSelection() throws Exception {
        assertTrue(repository.addBuild(build(121, true)));
        try { execute("UPDATE pokemon_builds SET selected_for_team=1 WHERE build_id=106"); fail("seventh update"); }
        catch (SQLException expected) { assertTrue(expected.getMessage().contains("at most 6")); }
        try { execute("INSERT INTO pokemon_builds VALUES(122,'Umbreon','Dark','','Wall',525,20,1,'2026-10-13')"); fail("seventh insert"); }
        catch (SQLException expected) { assertTrue(expected.getMessage().contains("at most 6")); }
    }

    /**
     * invalidStoredRowsAreRejectedDuringConnection checks incoming data validation.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void invalidStoredRowsAreRejectedDuringConnection() throws Exception {
        Path invalid = fixture(true);
        try (Connection other = fixtures.connect(invalid); Statement command = other.createStatement()) {
            command.execute("PRAGMA ignore_check_constraints=ON");
            command.execute("UPDATE pokemon_builds SET usage_rate='NaN' WHERE build_id=101");
        }
        assertFalse(repository.openDatabase(invalid.toString())); assertEquals(20, repository.count());
    }

    /**
     * externalCorruptionIsReportedWithoutOverwritingIt checks validation on later reads.
     * @throws Exception if test fixture access or an independent SQLite operation fails
     */
    @Test public void externalCorruptionIsReportedWithoutOverwritingIt() throws Exception {
        try (Connection other = fixtures.connect(database); Statement command = other.createStatement()) {
            command.execute("PRAGMA ignore_check_constraints=ON"); command.execute("UPDATE pokemon_builds SET base_stat_total=1.5 WHERE build_id=101");
        }
        try { repository.getAllBuilds(); fail("Expected corrupt row rejection"); }
        catch (DatabaseAccessException expected) { assertTrue(expected.getMessage().contains("base_stat_total")); }
    }

    /**
     * disconnectedChangesAreRejectedAndCloseIsRepeatable checks connection lifecycle.
     */
    @Test public void disconnectedChangesAreRejectedAndCloseIsRepeatable() {
        repository.close(); repository.close(); assertFalse(repository.isConnected());
        assertFalse(repository.addBuild(build(121, false))); assertFalse(repository.removeBuild(101));
        assertFalse(repository.updateBuild(101, build(121, false))); assertEquals(0, repository.count());
        assertTrue(repository.openDatabase(database.toString())); assertEquals(20, repository.count());
    }

    /**
     * returnedObjectsCannotMutateSavedRows checks separation of drafts and persistence.
     */
    @Test public void returnedObjectsCannotMutateSavedRows() {
        PokemonBuild draft = repository.findBuildById(101).get(); draft.setUsageRate(99);
        assertEquals(28.4, repository.findBuildById(101).get().getUsageRate(), 0);
        repository.getAllBuilds().clear(); assertEquals(20, repository.count());
    }
}
