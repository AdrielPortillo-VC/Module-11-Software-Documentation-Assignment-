package dms;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 * TestDatabases creates independent SQLite fixtures for database and GUI tests.
 *
 * <p>The schema and optional 20 seed records come from project-relative SQL
 * scripts. Callers own the returned files and JDBC connections and must delete
 * or close them after use. Run fixture creation from the project root.</p>
 *
 * <p>Class: TestDatabases. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class TestDatabases {
    /**
     * TestDatabases creates a stateless factory for isolated SQLite fixtures.
     */
    public TestDatabases() { }

    /**
     * create builds a fresh database for one test.
     *
     * @param populated whether to include the 20 demonstration records
     * @return an existing database path owned by the calling test
     * @throws Exception if a temporary file, SQL script, SQLite connection, or initialization statement fails
     */
    public Path create(boolean populated) throws Exception {
        Path path = Files.createTempFile("pokemon-dms-test-", ".db");
        try (Connection connection = connect(path); Statement statement = connection.createStatement()) {
            String schema = new String(Files.readAllBytes(Paths.get("database/schema.sql")), StandardCharsets.UTF_8);
            for (String part : schema.split("(?m)^-- statement-end\\s*$")) {
                if (!part.trim().isEmpty()) { statement.execute(part); }
            }
            if (populated) {
                String seed = new String(Files.readAllBytes(Paths.get("database/sample_data.sql")), StandardCharsets.UTF_8);
                for (String part : seed.split(";")) { if (!part.trim().isEmpty()) { statement.execute(part); } }
            }
        }
        return path;
    }

    /**
     * connect opens an independent observer, just as SQLiteStudio would.
     *
     * @param path fixture database location
     * @return a new JDBC connection that the caller must close
     * @throws Exception if the JDBC driver cannot load or the fixture connection cannot be opened
     */
    public Connection connect(Path path) throws Exception {
        Class.forName("org.sqlite.JDBC");
        return DriverManager.getConnection("jdbc:sqlite:" + path.toUri().toASCIIString());
    }
}
