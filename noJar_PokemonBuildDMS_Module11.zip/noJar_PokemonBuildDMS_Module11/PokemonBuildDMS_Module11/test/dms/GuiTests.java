package dms;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.WindowEvent;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Arrays;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * GuiTests exercises real Swing controls against isolated SQLite databases.
 *
 * <p>Actions and assertions run on the event dispatch thread. A test-specific
 * window supplies confirmation answers, avoiding modal interruptions while
 * preserving production workflows. Run on a graphical desktop or virtual display
 * from the project root. Fixtures and windows are released after each test.</p>
 *
 * <p>Class: GuiTests. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
 *
 * @author Adriel Portillo Perez
 * @version 11.0
 */
public class GuiTests {
    /**
     * GuiTests prepares collaborators; open() creates its database and Swing window.
     */
    public GuiTests() { }

    /**
     * Rules supplied to the test window and its repository.
     */
    private final BuildValidator validator = new BuildValidator();
    /**
     * Database repository isolated to the current GUI test.
     */
    private final SqliteBuildRepository repository = new SqliteBuildRepository(validator);
    /**
     * Factory for empty or populated test databases.
     */
    private final TestDatabases fixtures = new TestDatabases();
    /**
     * Fixture files owned by this test and deleted after it completes.
     */
    private final java.util.List<Path> databases = new java.util.ArrayList<Path>();
    /**
     * Current fixture used by the application and independent observers.
     */
    private Path activeDatabase;
    /**
     * Visible test window created and accessed on the event dispatch thread.
     */
    private TestWindow window;

    /**
     * TestWindow supplies repeatable confirmation responses for GUI regression tests.
     *
     * <p>Production workflows remain inherited from {@link PokemonBuildFrame}; only
     * the confirmation dialog is replaced, so tests can check approval and cancellation
     * without waiting for a person to respond.</p>
     *
     * <p>Class: TestWindow. Course: CEN 3024C. Documentation updated November 16, 2026.</p>
     *
     * @author Adriel Portillo Perez
     * @version 11.0
     */
    private class TestWindow extends PokemonBuildFrame {
        /**
         * Simulated Yes or No response for the next confirmation.
         */
        private boolean answer = true;
        /**
         * Most recent confirmation caption and consequence checked by assertions.
         */
        private String confirmation = "";
        /**
         * TestWindow reuses the test repository and calculator with simulated confirmations.
         */
        TestWindow() {
            super(validator, repository, new TeamReadinessCalculator(validator));
        }
        /**
         * confirm records the action and returns the simulated user's answer.
         *
         * @param title confirmation caption
         * @param message pending action description
         * @return the configured confirmation response
         */
        @Override protected boolean confirm(String title, String message) {
            confirmation = title + ": " + message;
            return answer;
        }
    }

    /**
     * open creates a visible, independent application window on the Swing thread.
     * @throws Exception if fixture creation, database connection, or Swing window creation fails
     */
    @Before public void open() throws Exception {
        activeDatabase = fixtures.create(false);
        databases.add(activeDatabase);
        assertTrue(repository.openDatabase(activeDatabase.toString()));
        onEdt(() -> { window = new TestWindow(); window.setVisible(true); });
    }

    /**
     * close disposes the test window even when an assertion fails.
     * @throws Exception if Swing cleanup, database close, or fixture-file deletion fails
     */
    @After public void close() throws Exception {
        onEdt(() -> { if (window != null) { window.dispose(); } repository.close(); });
        for (Path path : databases) { Files.deleteIfExists(path); }
    }

    /**
     * onEdt executes UI interaction on Swing's event dispatch thread.
     *
     * @param action GUI input or assertion to perform
     * @throws Exception if the caller is interrupted or the dispatched action throws an exception
     */
    private void onEdt(Runnable action) throws Exception { SwingUtilities.invokeAndWait(action); }

    /**
     * find traverses the component tree by a stable accessible name.
     *
     * @param root container or component to inspect
     * @param name expected component name
     * @return matching component or null
     */
    private Component find(Component root, String name) {
        if (name.equals(root.getName())) { return root; }
        if (root instanceof Container) {
            for (Component child : ((Container) root).getComponents()) {
                Component match = find(child, name);
                if (match != null) { return match; }
            }
        }
        return null;
    }

    /**
     * component retrieves a required named UI control.
     *
     * @param name stable UI identifier
     * @return matching component, failing the test if absent
     */
    private Component component(String name) {
        Component match = find(window, name);
        assertNotNull("Missing UI component: " + name, match);
        return match;
    }

    /**
     * text enters the value a user would type into a field.
     *
     * @param name target field name
     * @param value text to enter
     */
    private void text(String name, String value) { ((JTextField) component(name)).setText(value); }

    /**
     * choose selects an existing fixed-menu value.
     *
     * @param name combo box name
     * @param value allowed choice
     */
    private void choose(String name, String value) { ((JComboBox<?>) component(name)).setSelectedItem(value); }

    /**
     * click triggers an actual Swing action listener.
     *
     * @param name button name
     */
    private void click(String name) { ((JButton) component(name)).doClick(0); }

    /**
     * status reads the persistent message shown to the user.
     *
     * @return current status text
     */
    private String status() { return ((JTextArea) component("status")).getText(); }

    /**
     * table retrieves the visible build table.
     *
     * @return application table
     */
    private JTable table() { return (JTable) component("buildTable"); }

    /**
     * fill supplies all nine fields for a known valid draft.
     *
     * @param id record identifier
     * @param selected whether to include this build in the current team
     */
    private void fill(int id, boolean selected) {
        text("buildId", Integer.toString(id));
        choose("speciesName", "Garchomp");
        choose("primaryType", "Dragon");
        choose("secondaryType", "Ground");
        choose("role", "Sweeper");
        text("baseStatTotal", "600");
        text("usageRate", "20");
        ((JCheckBox) component("selectedForTeam")).setSelected(selected);
        text("lastUpdated", "2026-10-13");
    }

    /**
     * loadSample uses the normal database connection button with an isolated sample.
     */
    private void loadSample() {
        try {
            activeDatabase = fixtures.create(true); databases.add(activeDatabase);
            text("databasePath", activeDatabase.toString()); click("connectDatabase");
        } catch (Exception ex) { throw new AssertionError(ex); }
    }

    /**
     * emptyDisplayAndMenus verifies the startup menu, empty state, and Exit button.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void emptyDisplayAndMenus() throws Exception {
        onEdt(() -> {
            click("displayAll");
            assertEquals(0, table().getRowCount());
            assertTrue(status().contains("No builds"));
            assertEquals(3, window.getJMenuBar().getMenuCount());
            assertNotNull(component("exit"));
            assertEquals(JFrame.DO_NOTHING_ON_CLOSE, window.getDefaultCloseOperation());
            assertTrue(window.isShowing());
        });
    }

    /**
     * sampleConnectionDisplaysEveryField checks the 20 records and all nine columns.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void sampleConnectionDisplaysEveryField() throws Exception {
        onEdt(() -> {
            loadSample();
            assertEquals(20, repository.count());
            assertEquals(20, table().getRowCount());
            assertEquals(9, table().getColumnCount());
            assertEquals("Garchomp", table().getValueAt(0, 1));
            assertEquals(LocalDate.of(2026, 10, 13), table().getValueAt(0, 8));
            assertFalse(table().isCellEditable(0, 0));
        });
    }

    /**
     * invalidDatabaseLocationsPreserveData tests blank, missing, directory, and NUL paths.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void invalidDatabaseLocationsPreserveData() throws Exception {
        onEdt(() -> {
            loadSample();
            for (String value : new String[] {" ", "missing-gui-test.txt", ".", "\u0000"}) {
                text("databasePath", value);
                click("connectDatabase");
                assertTrue(status(), status().contains("Cannot open database"));
                assertEquals(20, repository.count());
                assertEquals(20, table().getRowCount());
                assertTrue(window.isShowing());
            }
        });
    }

    /**
     * repeatedConnectionDoesNotDuplicateRows verifies connection reload semantics.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void repeatedConnectionDoesNotDuplicateRows() throws Exception {
        onEdt(() -> {
            loadSample(); click("connectDatabase");
            assertEquals(20, repository.count()); assertEquals(20, table().getRowCount());
            assertTrue(status().contains("Loaded 20"));
        });
    }

    /**
     * invalidDatabaseFilePreservesTheCurrentConnection checks non-SQLite input.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void invalidDatabaseFilePreservesTheCurrentConnection() throws Exception {
        Path path = Files.createTempFile("dms-gui-invalid", ".db");
        try {
            Files.write(path, Arrays.asList("not a SQLite database"), StandardCharsets.UTF_8);
            onEdt(() -> {
                loadSample(); text("databasePath", path.toString()); click("connectDatabase");
                assertEquals(20, repository.count()); assertEquals(20, table().getRowCount());
                assertTrue(status().contains("Cannot open database")); assertTrue(window.isShowing());
            });
        } finally { Files.deleteIfExists(path); }
    }

    /**
     * addValidAndDuplicateRejected verifies validated form creation and duplicate IDs.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void addValidAndDuplicateRejected() throws Exception {
        onEdt(() -> {
            fill(121, false); click("addBuild");
            assertEquals(1, repository.count());
            assertEquals(121, table().getValueAt(0, 0));
            click("addBuild");
            assertEquals(1, repository.count());
            assertTrue(status().contains("already exists"));
            assertEquals("121", ((JTextField) component("buildId")).getText());
        });
    }

    /**
     * formRejectsNumericAndDateErrors exercises malformed text, overflow, and limits.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void formRejectsNumericAndDateErrors() throws Exception {
        onEdt(() -> {
            String[][] cases = {{"buildId", ""}, {"buildId", "abc"}, {"buildId", "0"},
                    {"buildId", "999999999999"}, {"baseStatTotal", "0"}, {"baseStatTotal", "721"},
                    {"baseStatTotal", "12.5"}, {"usageRate", "NaN"}, {"usageRate", "Infinity"},
                    {"usageRate", "1e9999"}, {"usageRate", "-1"}, {"usageRate", "101"},
                    {"lastUpdated", "2026-02-30"}, {"lastUpdated", "2999-01-01"},
                    {"lastUpdated", "1899-01-01"}, {"lastUpdated", ""}};
            for (String[] invalid : cases) {
                fill(121, false); text(invalid[0], invalid[1]); click("addBuild");
                assertEquals(Arrays.toString(invalid), 0, repository.count());
                assertTrue(status(), status().startsWith("Please correct:"));
                assertTrue(window.isShowing());
            }
        });
    }

    /**
     * catalogChoicesAndMissingFieldsRejectBadData checks fixed menus and required fields.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void catalogChoicesAndMissingFieldsRejectBadData() throws Exception {
        onEdt(() -> {
            for (String name : new String[] {"speciesName", "primaryType", "role"}) {
                fill(121, false);
                JComboBox<?> box = (JComboBox<?>) component(name);
                assertFalse(box.isEditable());
                box.setSelectedIndex(0); click("addBuild");
                assertEquals(0, repository.count());
            }
            fill(121, false); choose("secondaryType", "Dragon"); click("addBuild");
            assertEquals(0, repository.count());
            assertTrue(status().contains("must be different"));
        });
    }

    /**
     * updateAllNineFieldsIncludingId verifies every planned field can be edited.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void updateAllNineFieldsIncludingId() throws Exception {
        onEdt(() -> {
            loadSample(); text("targetId", "101"); click("findBuild");
            text("buildId", "121"); choose("speciesName", "Umbreon");
            choose("primaryType", "Dark"); choose("secondaryType", "None"); choose("role", "Other");
            text("baseStatTotal", "525"); text("usageRate", "30");
            ((JCheckBox) component("selectedForTeam")).setSelected(false);
            text("lastUpdated", "2026-10-14"); click("updateBuild");
            assertFalse(repository.containsId(101));
            assertEquals("121,Umbreon,Dark,,Other,525,30.0,false,2026-10-14",
                    repository.findBuildById(121).get().toCsvLine());
            assertEquals(20, table().getRowCount());
            assertEquals("Umbreon", table().getValueAt(table().getSelectedRow(), 1));
        });
    }

    /**
     * updateRejectsDuplicateIdAndBadFields verifies no partial update is committed.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void updateRejectsDuplicateIdAndBadFields() throws Exception {
        onEdt(() -> {
            loadSample(); String before = repository.findBuildById(101).get().toCsvLine();
            text("targetId", "101"); click("findBuild");
            text("buildId", "102"); text("usageRate", "30"); click("updateBuild");
            assertTrue(status().contains("already exists"));
            assertEquals(before, repository.findBuildById(101).get().toCsvLine());
            text("buildId", "121"); text("usageRate", "NaN"); click("updateBuild");
            assertEquals(before, repository.findBuildById(101).get().toCsvLine());
            assertFalse(repository.containsId(121));
        });
    }

    /**
     * sortedSelectionUpdatesTheCorrectRecord checks visual/model row conversion.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void sortedSelectionUpdatesTheCorrectRecord() throws Exception {
        onEdt(() -> {
            loadSample(); table().getRowSorter().toggleSortOrder(6);
            table().setRowSelectionInterval(0, 0);
            int id = (Integer) table().getValueAt(0, 0);
            assertEquals(119, id);
            text("usageRate", "77.5"); click("updateBuild");
            assertEquals(77.5, repository.findBuildById(id).get().getUsageRate(), 0);
            assertEquals(28.4, repository.findBuildById(101).get().getUsageRate(), 0);
        });
    }

    /**
     * removeExistingCanceledAndMissing verifies confirmation and safe missing IDs.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void removeExistingCanceledAndMissing() throws Exception {
        onEdt(() -> {
            loadSample(); text("targetId", "101");
            window.answer = false; click("removeBuild");
            assertTrue(repository.containsId(101));
            window.answer = true; click("removeBuild");
            assertTrue(window.confirmation.contains("Garchomp"));
            assertFalse(repository.containsId(101));
            assertEquals(19, table().getRowCount());
            text("targetId", "101"); click("removeBuild");
            assertTrue(status().contains("not found"));
            assertEquals(19, repository.count());
        });
    }

    /**
     * lookupAndUnselectedUpdateHandleMissingIds checks empty and nonexistent targets.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void lookupAndUnselectedUpdateHandleMissingIds() throws Exception {
        onEdt(() -> {
            click("updateBuild"); assertTrue(status().contains("Select a table row"));
            for (String id : new String[] {"", "abc", "999999999999", "999"}) {
                text("targetId", id); click("findBuild");
                assertTrue(status().startsWith("Please correct:"));
                click("removeBuild");
                assertEquals(0, repository.count());
            }
        });
    }

    /**
     * filtersSearchAndDisplayAll checks composable filters and literal punctuation.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void filtersSearchAndDisplayAll() throws Exception {
        onEdt(() -> {
            loadSample(); text("searchSpecies", "rotom-");
            assertEquals(1, table().getRowCount());
            text("searchSpecies", "["); assertEquals(0, table().getRowCount());
            click("displayAll"); choose("typeFilter", "Flying");
            assertEquals(5, table().getRowCount());
            choose("roleFilter", "Support"); assertEquals(1, table().getRowCount());
            click("displayAll"); ((JCheckBox) component("teamOnly")).doClick(0);
            assertEquals(5, table().getRowCount());
            click("displayAll"); assertEquals(20, table().getRowCount());
        });
    }

    /**
     * scoreMatchesKnownTeamAndIgnoresDisplayFilters tests the visible calculation.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void scoreMatchesKnownTeamAndIgnoresDisplayFilters() throws Exception {
        onEdt(() -> {
            loadSample(); text("searchSpecies", "Garchomp"); click("calculateScore");
            assertEquals("64.45 / 100", ((JLabel) component("scoreValue")).getText());
            String result = ((JTextArea) component("scoreReport")).getText();
            assertTrue(result.contains("Selected builds (5)"));
            assertTrue(result.contains("Average BST"));
            assertTrue(result.contains("Distinct roles"));
            text("targetId", "101"); click("findBuild"); text("usageRate", "50"); click("updateBuild");
            assertEquals("-- / 100", ((JLabel) component("scoreValue")).getText());
        });
    }

    /**
     * emptyTeamAndSeventhSelectionRejected checks both GUI team size boundaries.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void emptyTeamAndSeventhSelectionRejected() throws Exception {
        onEdt(() -> {
            click("calculateScore"); assertTrue(status().contains("Select 1 to 6"));
            for (int id = 1; id <= 6; id++) { fill(id, true); click("addBuild"); }
            fill(7, true); click("addBuild");
            assertEquals(6, repository.count()); assertTrue(status().contains("at most 6"));
            click("calculateScore"); assertFalse(((JLabel) component("scoreValue")).getText().startsWith("--"));
        });
    }

    /**
     * lowerCaseDatabaseSpeciesCanBeEdited preserves case-insensitive catalog behavior.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void lowerCaseDatabaseSpeciesCanBeEdited() throws Exception {
        onEdt(() -> {
            assertTrue(repository.addBuild(new PokemonBuild(1, "umbreon", "Dark", "", "Wall", 525, 20,
                    false, LocalDate.of(2026, 10, 13))));
            click("displayAll"); text("targetId", "1"); click("findBuild");
            assertEquals("Umbreon", ((JComboBox<?>) component("speciesName")).getSelectedItem());
            text("usageRate", "30"); click("updateBuild");
            assertEquals("Umbreon", repository.findBuildById(1).get().getSpeciesName());
        });
    }

    /**
     * externalUpdateAndDeleteAppearAfterDisplayAll checks the GUI database refresh.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void externalUpdateAndDeleteAppearAfterDisplayAll() throws Exception {
        onEdt(() -> { loadSample(); click("calculateScore"); });
        try (java.sql.Connection observer = fixtures.connect(activeDatabase); java.sql.Statement sql = observer.createStatement()) {
            sql.execute("UPDATE pokemon_builds SET usage_rate=77.5 WHERE build_id=101");
            sql.execute("DELETE FROM pokemon_builds WHERE build_id=102");
        }
        onEdt(() -> {
            click("displayAll"); assertEquals(19, table().getRowCount());
            assertEquals(77.5, (Double) table().getValueAt(0, 6), 0);
            assertEquals("-- / 100", ((JLabel) component("scoreValue")).getText());
        });
    }

    /**
     * findReadsCurrentDatabaseValues checks editing after an external database change.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void findReadsCurrentDatabaseValues() throws Exception {
        onEdt(() -> loadSample());
        try (java.sql.Connection observer = fixtures.connect(activeDatabase); java.sql.Statement sql = observer.createStatement()) {
            sql.execute("UPDATE pokemon_builds SET usage_rate=77.5 WHERE build_id=101");
            sql.execute("INSERT INTO pokemon_builds VALUES(121,'Umbreon','Dark','','Wall',525,20,0,'2026-10-13')");
        }
        onEdt(() -> {
            text("targetId", "101"); click("findBuild");
            assertEquals("77.5", ((JTextField) component("usageRate")).getText());
            text("targetId", "121"); click("findBuild");
            assertEquals("Umbreon", ((JComboBox<?>) component("speciesName")).getSelectedItem());
            assertEquals(21, table().getRowCount());
        });
    }

    /**
     * guiWritesReachAnIndependentObserver checks the actual button-to-SQL path.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void guiWritesReachAnIndependentObserver() throws Exception {
        onEdt(() -> { fill(121, false); click("addBuild"); });
        try (java.sql.Connection observer = fixtures.connect(activeDatabase); java.sql.Statement sql = observer.createStatement()) {
            try (java.sql.ResultSet row = sql.executeQuery("SELECT species_name FROM pokemon_builds WHERE build_id=121")) {
                assertTrue(row.next()); assertEquals("Garchomp", row.getString(1));
            }
            onEdt(() -> { text("usageRate", "44.5"); click("updateBuild"); });
            try (java.sql.ResultSet row = sql.executeQuery("SELECT usage_rate FROM pokemon_builds WHERE build_id=121")) {
                assertTrue(row.next()); assertEquals(44.5, row.getDouble(1), 0);
            }
            onEdt(() -> { text("targetId", "121"); click("removeBuild"); });
            try (java.sql.ResultSet row = sql.executeQuery("SELECT COUNT(*) FROM pokemon_builds")) {
                assertTrue(row.next()); assertEquals(0, row.getInt(1));
            }
        }
    }

    /**
     * unreadableDatabaseErrorsStayInsideGui checks recovery from externally corrupted data.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void unreadableDatabaseErrorsStayInsideGui() throws Exception {
        onEdt(() -> loadSample());
        try (java.sql.Connection observer = fixtures.connect(activeDatabase); java.sql.Statement sql = observer.createStatement()) {
            sql.execute("PRAGMA ignore_check_constraints=ON"); sql.execute("UPDATE pokemon_builds SET usage_rate=101 WHERE build_id=101");
        }
        onEdt(() -> {
            click("displayAll"); assertTrue(status().contains("Cannot read database"));
            assertEquals(20, table().getRowCount()); assertTrue(window.isShowing());
        });
    }

    /**
     * exitButtonAndTitleBarRespectCancel checks every supported application exit path.
     * @throws Exception if fixture access or event dispatch fails before the assertions complete
     */
    @Test public void exitButtonAndTitleBarRespectCancel() throws Exception {
        onEdt(() -> {
            fill(1, false); click("addBuild");
            window.answer = false; click("exit"); assertTrue(window.isShowing());
            assertTrue(window.confirmation.contains("already saved"));
            window.dispatchEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
            assertTrue(window.isShowing());
            window.answer = true; click("exit"); assertFalse(window.isDisplayable());
        });
    }
}
