#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
sh build.sh
mkdir -p build/test-classes
if javac -version 2>&1 | sed -n '1p' | cut -d ' ' -f 2 | cut -d '.' -f 1 | grep -qx 1; then
  javac -encoding UTF-8 -source 8 -target 8 -cp 'build/classes:lib/*' -d build/test-classes test/dms/*.java
else
  javac -encoding UTF-8 --release 8 -cp 'build/classes:lib/*' -d build/test-classes test/dms/*.java
fi
java -cp 'build/classes:build/test-classes:lib/*' org.junit.runner.JUnitCore dms.DmsTests dms.DatabaseTests dms.GuiTests
