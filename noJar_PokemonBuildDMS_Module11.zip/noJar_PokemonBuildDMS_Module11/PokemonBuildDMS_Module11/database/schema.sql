-- Adriel Portillo Perez | CEN 3024C | November 9, 2026
-- SQLite 3 schema for the nine-field Pokemon Build DMS.
-- Apply only to a new, empty database; do not run over work you want to keep.
CREATE TABLE pokemon_builds (
    build_id INTEGER PRIMARY KEY CHECK(build_id BETWEEN 1 AND 2147483647),
    species_name TEXT NOT NULL COLLATE NOCASE CHECK(species_name IN ('Garchomp','Rotom-Heat','Corviknight','Whimsicott','Gyarados','Sceptile','Incineroar','Amoonguss','Togekiss','Dragapult','Tyranitar','Excadrill','Milotic','Gastrodon','Grimmsnarl','Pelipper','Rillaboom','Cinderace','Venusaur','Charizard','Umbreon','Lucario','Pikachu','Absol','Maushold','Volcarona')),
    primary_type TEXT NOT NULL CHECK(primary_type IN ('Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy')),
    secondary_type TEXT NOT NULL DEFAULT '' CHECK(secondary_type = '' OR secondary_type IN ('Normal','Fire','Water','Electric','Grass','Ice','Fighting','Poison','Ground','Flying','Psychic','Bug','Rock','Ghost','Dragon','Dark','Steel','Fairy')),
    role TEXT NOT NULL CHECK(role IN ('Sweeper','Wall','Pivot','Support','Lead','Other')),
    base_stat_total INTEGER NOT NULL CHECK(typeof(base_stat_total) = 'integer' AND base_stat_total BETWEEN 1 AND 720),
    usage_rate REAL NOT NULL CHECK(typeof(usage_rate) IN ('integer','real') AND usage_rate BETWEEN 0 AND 100),
    selected_for_team INTEGER NOT NULL CHECK(typeof(selected_for_team) = 'integer' AND selected_for_team IN (0,1)),
    last_updated TEXT NOT NULL CHECK(length(last_updated) = 10
        AND last_updated GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'
        AND date(last_updated, '+0 days') IS NOT NULL
        AND date(last_updated, '+0 days') = last_updated AND last_updated >= '1900-01-01'),
    CHECK(primary_type <> secondary_type)
);
-- statement-end
CREATE TRIGGER limit_team_insert BEFORE INSERT ON pokemon_builds
WHEN NEW.selected_for_team = 1 AND (SELECT COUNT(*) FROM pokemon_builds WHERE selected_for_team = 1) >= 6
BEGIN SELECT RAISE(ABORT, 'A team can have at most 6 selected builds.'); END;
-- statement-end
CREATE TRIGGER limit_team_update BEFORE UPDATE ON pokemon_builds
WHEN NEW.selected_for_team = 1 AND (SELECT COUNT(*) FROM pokemon_builds WHERE selected_for_team = 1 AND build_id <> OLD.build_id) >= 6
BEGIN SELECT RAISE(ABORT, 'A team can have at most 6 selected builds.'); END;
-- statement-end
CREATE TRIGGER valid_date_insert BEFORE INSERT ON pokemon_builds
WHEN NEW.last_updated > date('now', 'localtime')
BEGIN SELECT RAISE(ABORT, 'Last updated cannot be in the future.'); END;
-- statement-end
CREATE TRIGGER valid_date_update BEFORE UPDATE ON pokemon_builds
WHEN NEW.last_updated > date('now', 'localtime')
BEGIN SELECT RAISE(ABORT, 'Last updated cannot be in the future.'); END;
-- statement-end
