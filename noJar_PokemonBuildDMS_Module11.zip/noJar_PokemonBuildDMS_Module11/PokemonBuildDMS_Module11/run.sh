#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
exec java -jar dist/PokemonBuildDMS_Module11.jar
