#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
documentation_classpath='lib/sqlite-jdbc-3.50.3.0.jar:lib/slf4j-api-2.0.17.jar:lib/slf4j-nop-2.0.17.jar:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar'
javadoc --release 8 -encoding UTF-8 -docencoding UTF-8 -charset UTF-8 \
  -private -author -version -notimestamp -Xdoclint:all -Werror \
  -windowtitle 'Pokemon Build DMS - Module 11' \
  -doctitle 'Pokemon Build DMS: Module 11 Javadoc' \
  -overview docs/overview.html -d docs/javadoc \
  -classpath "$documentation_classpath" @javadoc-sources.txt
printf '%s\n' 'Javadoc generated: docs/javadoc/index.html'
